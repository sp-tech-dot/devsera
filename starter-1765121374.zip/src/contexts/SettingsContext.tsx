import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';

interface PaymentSettings {
  upiId: string;
  qrCodeImage: string | null;
  telegramLink: string;
  telegramCommunityLink: string;
  whatsappSupport: string;
}

interface SettingsContextType {
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: Partial<PaymentSettings>) => Promise<void>;
  loading: boolean;
}

const defaultSettings: PaymentSettings = {
  upiId: 'devsera@upi',
  qrCodeImage: null,
  telegramLink: 'https://t.me/devserastore',
  telegramCommunityLink: 'https://t.me/devseracommunity',
  whatsappSupport: '+91 98765 43210'
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  // Fetch settings from Supabase on mount
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const { data, error } = await supabase
          .from('settings')
          .select('key, value');

        if (error) throw error;

        if (data && data.length > 0) {
          const settingsMap: Record<string, string> = {};
          data.forEach(item => {
            settingsMap[item.key] = item.value;
          });

          setPaymentSettings({
            upiId: settingsMap['upi_id'] || defaultSettings.upiId,
            qrCodeImage: settingsMap['qr_code_image'] || null,
            telegramLink: settingsMap['telegram_link'] || defaultSettings.telegramLink,
            telegramCommunityLink: settingsMap['telegram_community_link'] || defaultSettings.telegramCommunityLink,
            whatsappSupport: settingsMap['whatsapp_support'] || defaultSettings.whatsappSupport
          });
        }
      } catch (error) {
        console.error('Error fetching settings:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSettings();
  }, []);

  const updatePaymentSettings = useCallback(async (settings: Partial<PaymentSettings>) => {
    try {
      // Map frontend keys to database keys
      const keyMap: Record<string, string> = {
        upiId: 'upi_id',
        qrCodeImage: 'qr_code_image',
        telegramLink: 'telegram_link',
        telegramCommunityLink: 'telegram_community_link',
        whatsappSupport: 'whatsapp_support'
      };

      // Update each setting in the database
      for (const [key, value] of Object.entries(settings)) {
        const dbKey = keyMap[key];
        if (dbKey) {
          await supabase
            .from('settings')
            .upsert({ key: dbKey, value: value || '' }, { onConflict: 'key' });
        }
      }

      // Update local state
      setPaymentSettings(prev => ({ ...prev, ...settings }));
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  }, []);

  return (
    <SettingsContext.Provider value={{
      paymentSettings,
      updatePaymentSettings,
      loading
    }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
