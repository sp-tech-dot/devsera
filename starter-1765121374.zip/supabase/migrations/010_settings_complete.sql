CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

DROP TRIGGER IF EXISTS settings_updated_at ON settings;
CREATE TRIGGER settings_updated_at BEFORE UPDATE ON settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();

INSERT INTO settings (key, value) VALUES 
  ('upi_id', 'devsera@upi'),
  ('qr_code_image', ''),
  ('telegram_link', 'https://t.me/devserastore'),
  ('telegram_community_link', 'https://t.me/devseracommunity'),
  ('whatsapp_support', '+91 98765 43210')
ON CONFLICT (key) DO NOTHING;
