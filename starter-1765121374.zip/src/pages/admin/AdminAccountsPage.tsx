import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useOrders } from '@/contexts/OrderContext';
import { supabase, DbAccountPool } from '@/lib/supabase';
import { AccountPool } from '@/types';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Plus, 
  Edit2, 
  Trash2,
  Loader2
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const statusColors = {
  available: 'bg-emerald-100 text-emerald-800 border-emerald-300',
  assigned: 'bg-blue-100 text-blue-800 border-blue-300',
  blocked: 'bg-red-100 text-red-800 border-red-300'
};

export function AdminAccountsPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { products } = useOrders();
  const [accounts, setAccounts] = useState<AccountPool[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingAccount, setEditingAccount] = useState<AccountPool | null>(null);
  const [processing, setProcessing] = useState(false);
  const [formData, setFormData] = useState({
    productId: '',
    email: '',
    password: '',
    platformLink: '',
    expiryDate: '',
    status: 'available' as AccountPool['status']
  });

  // Fetch accounts from Supabase
  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const { data, error } = await supabase
          .from('account_pool')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;

        const mappedAccounts: AccountPool[] = (data || []).map((acc: DbAccountPool) => ({
          id: acc.id,
          productId: acc.product_id,
          email: acc.email,
          password: acc.password,
          platformLink: acc.platform_link,
          expiryDate: acc.expiry_date,
          status: acc.status
        }));

        setAccounts(mappedAccounts);
      } catch (error) {
        console.error('Error fetching accounts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAccounts();
  }, []);

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  const resetForm = () => {
    setFormData({
      productId: '',
      email: '',
      password: '',
      platformLink: '',
      expiryDate: '',
      status: 'available'
    });
  };

  const handleAdd = async () => {
    setProcessing(true);
    try {
      const { data, error } = await supabase
        .from('account_pool')
        .insert({
          product_id: formData.productId,
          email: formData.email,
          password: formData.password,
          platform_link: formData.platformLink,
          expiry_date: formData.expiryDate,
          status: formData.status
        })
        .select()
        .single();

      if (error) throw error;

      const newAccount: AccountPool = {
        id: data.id,
        productId: data.product_id,
        email: data.email,
        password: data.password,
        platformLink: data.platform_link,
        expiryDate: data.expiry_date,
        status: data.status
      };
      
      setAccounts(prev => [newAccount, ...prev]);
      setShowAddDialog(false);
      resetForm();
    } catch (error) {
      console.error('Error adding account:', error);
    } finally {
      setProcessing(false);
    }
  };

  const handleEdit = async () => {
    if (!editingAccount) return;
    
    setProcessing(true);
    try {
      const { error } = await supabase
        .from('account_pool')
        .update({
          product_id: formData.productId,
          email: formData.email,
          password: formData.password,
          platform_link: formData.platformLink,
          expiry_date: formData.expiryDate,
          status: formData.status
        })
        .eq('id', editingAccount.id);

      if (error) throw error;
      
      setAccounts(prev => prev.map(acc => 
        acc.id === editingAccount.id 
          ? { ...acc, ...formData }
          : acc
      ));
      
      setEditingAccount(null);
      resetForm();
    } catch (error) {
      console.error('Error updating account:', error);
    } finally {
      setProcessing(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('account_pool')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setAccounts(prev => prev.filter(acc => acc.id !== id));
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  };

  const openEditDialog = (account: AccountPool) => {
    setEditingAccount(account);
    setFormData({
      productId: account.productId,
      email: account.email,
      password: account.password,
      platformLink: account.platformLink,
      expiryDate: account.expiryDate,
      status: account.status
    });
  };

  const getProductName = (productId: string) => {
    return products.find(p => p.id === productId)?.name || 'Unknown';
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/admin')}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Dashboard</span>
        </button>

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-bold text-4xl mb-2">Account Pool</h1>
            <p className="text-gray-600">Manage available accounts for products</p>
          </div>
          <Button
            onClick={() => setShowAddDialog(true)}
            className="bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Account
          </Button>
        </div>

        {/* Accounts Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-2 border-black shadow-brutalist overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-black">
                <tr>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Product</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Email</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Status</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Expiry</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {accounts.map(account => (
                  <tr key={account.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <span className="font-medium">{getProductName(account.productId)}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-sm">{account.email}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium border rounded ${statusColors[account.status]}`}>
                        {account.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {format(new Date(account.expiryDate), 'MMM d, yyyy')}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(account)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(account.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {accounts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No accounts in pool</p>
            </div>
          )}
        </motion.div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog 
        open={showAddDialog || !!editingAccount} 
        onOpenChange={(open) => {
          if (!open) {
            setShowAddDialog(false);
            setEditingAccount(null);
            resetForm();
          }
        }}
      >
        <DialogContent className="border-2 border-black">
          <DialogHeader>
            <DialogTitle className="font-display">
              {editingAccount ? 'Edit Account' : 'Add New Account'}
            </DialogTitle>
            <DialogDescription>
              {editingAccount ? 'Update account details' : 'Add a new account to the pool'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Product</Label>
              <Select
                value={formData.productId}
                onValueChange={(value) => setFormData(prev => ({ ...prev, productId: value }))}
              >
                <SelectTrigger className="border-2 border-black">
                  <SelectValue placeholder="Select product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="acc-email">Email</Label>
              <Input
                id="acc-email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="border-2 border-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="acc-password">Password</Label>
              <Input
                id="acc-password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                className="border-2 border-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="acc-platform">Platform Link</Label>
              <Input
                id="acc-platform"
                value={formData.platformLink}
                onChange={(e) => setFormData(prev => ({ ...prev, platformLink: e.target.value }))}
                className="border-2 border-black"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="acc-expiry">Expiry Date</Label>
              <Input
                id="acc-expiry"
                type="date"
                value={formData.expiryDate}
                onChange={(e) => setFormData(prev => ({ ...prev, expiryDate: e.target.value }))}
                className="border-2 border-black"
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: AccountPool['status']) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger className="border-2 border-black">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowAddDialog(false);
                setEditingAccount(null);
                resetForm();
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={editingAccount ? handleEdit : handleAdd}
              disabled={processing || !formData.productId || !formData.email}
              className="bg-[#0A7A7A] hover:bg-[#086666] text-white"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : editingAccount ? (
                'Update Account'
              ) : (
                'Add Account'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
