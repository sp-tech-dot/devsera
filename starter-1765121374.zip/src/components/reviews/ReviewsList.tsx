import { Review } from '@/types';
import { ReviewCard } from './ReviewCard';
import { Star } from 'lucide-react';

interface ReviewsListProps {
  reviews: Review[];
  averageRating?: number;
  totalReviews?: number;
}

export function ReviewsList({ reviews, averageRating, totalReviews }: ReviewsListProps) {
  return (
    <div className="space-y-8">
      {averageRating !== undefined && totalReviews !== undefined && (
        <div className="border-2 border-black p-8 bg-white text-center"
          style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="text-6xl font-bold">{averageRating.toFixed(1)}</span>
            <Star className="w-12 h-12 fill-amber-400 text-amber-400" />
          </div>
          <p className="text-gray-600 uppercase tracking-wide text-sm">
            Based on {totalReviews} {totalReviews === 1 ? 'review' : 'reviews'}
          </p>
        </div>
      )}

      <div className="space-y-4">
        {reviews.length === 0 ? (
          <div className="border-2 border-black p-12 bg-white text-center">
            <p className="text-gray-600">No reviews yet. Be the first to review!</p>
          </div>
        ) : (
          reviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))
        )}
      </div>
    </div>
  );
}
