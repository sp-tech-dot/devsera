import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { User, LogOut, ShoppingBag, LayoutDashboard, Menu } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b-2 border-black bg-[#FAFAF8]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#0A7A7A] border-2 border-black shadow-brutalist flex items-center justify-center">
              <span className="text-white font-display font-bold text-lg">D</span>
            </div>
            <span className="font-display font-bold text-xl hidden sm:block">Devsera Store</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link 
              to="/products" 
              className="font-medium text-sm hover:text-[#0A7A7A] transition-colors"
            >
              Products
            </Link>
            <Link 
              to="/community" 
              className="font-medium text-sm hover:text-[#0A7A7A] transition-colors"
            >
              Community
            </Link>
            <Link 
              to="/faq" 
              className="font-medium text-sm hover:text-[#0A7A7A] transition-colors"
            >
              FAQ
            </Link>
            {isAuthenticated && (
              <Link 
                to="/orders" 
                className="font-medium text-sm hover:text-[#0A7A7A] transition-colors"
              >
                My Orders
              </Link>
            )}
            {user?.isAdmin && (
              <Link 
                to="/admin" 
                className="font-medium text-sm hover:text-[#0A7A7A] transition-colors"
              >
                Admin
              </Link>
            )}
          </nav>

          {/* Auth Section */}
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="border-2 border-black shadow-brutalist hover:shadow-none transition-shadow"
                  >
                    <User className="h-4 w-4 mr-2" />
                    <span className="hidden sm:inline">{user?.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48 border-2 border-black">
                  <DropdownMenuItem onClick={() => navigate('/orders')}>
                    <ShoppingBag className="h-4 w-4 mr-2" />
                    My Orders
                  </DropdownMenuItem>
                  {user?.isAdmin && (
                    <DropdownMenuItem onClick={() => navigate('/admin')}>
                      <LayoutDashboard className="h-4 w-4 mr-2" />
                      Admin Dashboard
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-red-600">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-2">
                <Button 
                  variant="ghost" 
                  onClick={() => navigate('/login')}
                  className="hidden sm:flex"
                >
                  Login
                </Button>
                <Button 
                  onClick={() => navigate('/register')}
                  className="bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none transition-all active:scale-[0.98]"
                >
                  Sign Up
                </Button>
              </div>
            )}

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col gap-2">
              <Link 
                to="/products" 
                className="px-4 py-3 font-medium hover:bg-gray-100 rounded text-sm"
                onClick={() => setMobileMenuOpen(false)}
              >
                Products
              </Link>
              <Link 
                to="/community" 
                className="px-4 py-3 font-medium hover:bg-gray-100 rounded text-sm"
                onClick={() => setMobileMenuOpen(false)}
              >
                Community
              </Link>
              <Link 
                to="/faq" 
                className="px-4 py-3 font-medium hover:bg-gray-100 rounded text-sm"
                onClick={() => setMobileMenuOpen(false)}
              >
                FAQ
              </Link>
              {isAuthenticated && (
                <Link 
                  to="/orders" 
                  className="px-4 py-3 font-medium hover:bg-gray-100 rounded text-sm"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  My Orders
                </Link>
              )}
              {user?.isAdmin && (
                <Link 
                  to="/admin" 
                  className="px-4 py-3 font-medium hover:bg-gray-100 rounded text-sm"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Admin Dashboard
                </Link>
              )}
              {!isAuthenticated && (
                <div className="px-4 py-2 space-y-2">
                  <Button 
                    variant="ghost" 
                    onClick={() => {
                      navigate('/login');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full justify-start text-sm"
                  >
                    Login
                  </Button>
                  <Button 
                    onClick={() => {
                      navigate('/register');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none transition-all text-sm"
                  >
                    Sign Up
                  </Button>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
