-- ============================================
-- DEVSERA STORE - COMPLETE DATABASE SETUP
-- Run this entire file in Supabase SQL Editor
-- ============================================

-- 1. Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  whatsapp TEXT,
  telegram TEXT,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create products table
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  features TEXT[],
  original_price NUMERIC(10,2) NOT NULL,
  price NUMERIC(10,2) NOT NULL,
  duration_days INTEGER NOT NULL,
  delivery_time TEXT NOT NULL,
  image_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'pending',
  payment_screenshot_url TEXT,
  assigned_email TEXT,
  assigned_password TEXT,
  platform_link TEXT,
  expiry_date DATE,
  cancellation_reason TEXT,
  total_amount NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Create order_status_logs table
CREATE TABLE IF NOT EXISTS order_status_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  note TEXT,
  actor_id UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Create account_pool table
CREATE TABLE IF NOT EXISTS account_pool (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  platform_link TEXT,
  is_assigned BOOLEAN DEFAULT FALSE,
  is_blocked BOOLEAN DEFAULT FALSE,
  expiry_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Create settings table
CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Disable RLS for development
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;
ALTER TABLE products DISABLE ROW LEVEL SECURITY;
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE order_status_logs DISABLE ROW LEVEL SECURITY;
ALTER TABLE account_pool DISABLE ROW LEVEL SECURITY;
ALTER TABLE settings DISABLE ROW LEVEL SECURITY;

-- 8. Insert sample products
INSERT INTO products (name, slug, description, features, original_price, price, duration_days, delivery_time, image_url) VALUES
('Canva Pro', 'canva-pro', 'Professional design tools with premium templates and assets', ARRAY['Unlimited premium templates', 'Brand kit', 'Background remover', 'Magic resize'], 12.99, 4.99, 30, '2-4 hours', 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80'),
('LinkedIn Premium', 'linkedin-premium', 'Boost your career with LinkedIn Premium features', ARRAY['InMail messages', 'Who viewed your profile', 'LinkedIn Learning access', 'Applicant insights'], 29.99, 9.99, 30, '4-6 hours', 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?w=800&q=80'),
('Netflix Premium', 'netflix-premium', 'Shared Netflix Premium account with 4K streaming', ARRAY['4K Ultra HD', '4 screens at once', 'Download on 6 devices', 'No ads'], 19.99, 7.99, 30, '1-2 hours', 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=800&q=80'),
('Spotify Premium', 'spotify-premium', 'Ad-free music streaming with offline downloads', ARRAY['Ad-free listening', 'Offline downloads', 'High quality audio', 'Unlimited skips'], 9.99, 3.99, 30, '2-3 hours', 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=800&q=80'),
('Adobe Creative Cloud', 'adobe-cc', 'Complete Adobe Creative Cloud suite access', ARRAY['Photoshop', 'Illustrator', 'Premiere Pro', 'After Effects', '100GB cloud storage'], 54.99, 19.99, 30, '6-12 hours', 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&q=80'),
('YouTube Premium', 'youtube-premium', 'Ad-free YouTube with background play and downloads', ARRAY['Ad-free videos', 'Background play', 'Offline downloads', 'YouTube Music Premium'], 11.99, 4.99, 30, '2-4 hours', 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=800&q=80')
ON CONFLICT (slug) DO NOTHING;

-- 9. Insert default settings
INSERT INTO settings (key, value) VALUES
('upi_id', 'devsera@paytm'),
('telegram_support', 'https://t.me/devserasupport'),
('whatsapp_support', '+919876543210')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- 10. Create admin user function
CREATE OR REPLACE FUNCTION create_admin_user()
RETURNS void AS $$
DECLARE
  admin_user_id UUID;
BEGIN
  -- Check if admin already exists
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'admin@devsera.store') THEN
    -- Insert into auth.users
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@devsera.store',
      crypt('Stevesp123@', gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Admin User"}',
      NOW(),
      NOW(),
      '',
      '',
      '',
      ''
    ) RETURNING id INTO admin_user_id;

    -- Insert into profiles
    INSERT INTO profiles (id, email, full_name, is_admin)
    VALUES (admin_user_id, 'admin@devsera.store', 'Admin User', TRUE);
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. Execute admin user creation
SELECT create_admin_user();

-- ============================================
-- SETUP COMPLETE!
-- Admin Login: admin@devsera.store
-- Password: Stevesp123@
-- ============================================
