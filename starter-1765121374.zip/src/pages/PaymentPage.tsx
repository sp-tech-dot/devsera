import { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import { Copy, Check, Upload, MessageCircle, ArrowLeft, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

export function PaymentPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { getOrderById, submitPayment } = useOrders();
  const { isAuthenticated } = useAuth();
  const { paymentSettings } = useSettings();
  
  const [copied, setCopied] = useState(false);
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const order = orderId ? getOrderById(orderId) : undefined;

  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  if (!order) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="font-display font-bold text-3xl mb-4">Order Not Found</h1>
          <Button onClick={() => navigate('/orders')}>View My Orders</Button>
        </div>
      </Layout>
    );
  }

  const handleCopyUPI = async () => {
    await navigator.clipboard.writeText(paymentSettings.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitPayment = async () => {
    if (!screenshot) return;
    
    setUploading(true);
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    submitPayment(order.id, screenshot);
    setUploading(false);
    setSubmitted(true);
    
    // Redirect to order detail after 2 seconds
    setTimeout(() => {
      navigate(`/orders/${order.id}`);
    }, 2000);
  };

  if (submitted) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', duration: 0.5 }}
            className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <Check className="h-10 w-10 text-white" />
          </motion.div>
          <h1 className="font-display font-bold text-3xl mb-4">Payment Submitted!</h1>
          <p className="text-gray-600 mb-4">
            Your payment is being verified. You'll receive your credentials soon.
          </p>
          <p className="text-sm text-gray-500">Redirecting to order details...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 sm:mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back</span>
        </button>

        <div className="max-w-2xl mx-auto">
          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border-2 border-black shadow-brutalist p-4 sm:p-6 mb-6 sm:mb-8"
          >
            <h2 className="font-display font-bold text-lg sm:text-xl mb-4">Order Summary</h2>
            <div className="flex items-center gap-3 sm:gap-4 mb-4">
              <img 
                src={order.product.image} 
                alt={order.product.name}
                className="w-12 h-12 sm:w-16 sm:h-16 object-cover border-2 border-black"
              />
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-sm sm:text-base truncate">{order.product.name}</h3>
                <p className="text-xs sm:text-sm text-gray-600">{order.product.duration}</p>
              </div>
              <div className="text-right">
                <p className="font-display font-bold text-lg sm:text-xl text-[#0A7A7A]">
                  ₹{order.product.price}
                </p>
              </div>
            </div>
            <div className="border-t border-gray-200 pt-4">
              <p className="text-xs sm:text-sm text-gray-600">
                Order ID: <span className="font-mono font-medium break-all">{order.id}</span>
              </p>
            </div>
          </motion.div>

          {/* Payment Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white border-2 border-black shadow-brutalist-lg p-6 sm:p-8"
          >
            <h1 className="font-display font-bold text-xl sm:text-2xl mb-6 text-center">
              Complete Payment
            </h1>

            {/* QR Code */}
            <div className="flex justify-center mb-6 sm:mb-8">
              <div className="border-4 border-black p-3 sm:p-4 shadow-brutalist-lg bg-white">
                {paymentSettings.qrCodeImage ? (
                  <img
                    src={paymentSettings.qrCodeImage}
                    alt="UPI QR Code"
                    className="w-[200px] h-[200px] sm:w-[250px] sm:h-[250px] object-contain"
                  />
                ) : (
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${paymentSettings.upiId}&pn=Devsera%20Store&am=${order.product.price}&cu=INR`}
                    alt="UPI QR Code"
                    className="w-[200px] h-[200px] sm:w-[250px] sm:h-[250px]"
                  />
                )}
              </div>
            </div>

            {/* UPI ID */}
            <div className="mb-6 sm:mb-8">
              <p className="text-center text-gray-600 mb-2 text-sm sm:text-base">Or pay using UPI ID:</p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                <code className="font-mono text-sm sm:text-lg bg-gray-100 px-3 sm:px-4 py-2 border-2 border-black break-all">
                  {paymentSettings.upiId}
                </code>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleCopyUPI}
                  className="border-2 border-black"
                >
                  {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            {/* Amount */}
            <div className="text-center mb-8 p-4 bg-[#0A7A7A]/10 border-2 border-[#0A7A7A]">
              <p className="text-sm text-gray-600 mb-1">Amount to Pay</p>
              <p className="font-display font-bold text-3xl text-[#0A7A7A]">
                ₹{order.product.price}
              </p>
            </div>

            {/* Screenshot Upload */}
            <div className="mb-6">
              <p className="font-medium mb-3">Upload Payment Screenshot</p>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
              
              {screenshot ? (
                <div className="relative">
                  <img 
                    src={screenshot} 
                    alt="Payment screenshot" 
                    className="w-full max-h-64 object-contain border-2 border-black"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute top-2 right-2 border-2 border-black bg-white"
                  >
                    Change
                  </Button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full border-2 border-dashed border-gray-300 hover:border-[#0A7A7A] p-8 text-center transition-colors"
                >
                  <Upload className="h-10 w-10 mx-auto mb-3 text-gray-400" />
                  <p className="text-gray-600">Click to upload screenshot</p>
                  <p className="text-sm text-gray-400 mt-1">PNG, JPG up to 5MB</p>
                </button>
              )}
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmitPayment}
              disabled={!screenshot || uploading}
              className="w-full bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none transition-all active:scale-[0.98] py-6 text-lg"
            >
              {uploading ? (
                <>
                  <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Payment'
              )}
            </Button>

            {/* Help Link */}
            <div className="mt-6 text-center">
              <a
                href={paymentSettings.telegramLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-[#0A7A7A] hover:underline"
              >
                <MessageCircle className="h-4 w-4" />
                <span>Need help? Contact us on Telegram</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
