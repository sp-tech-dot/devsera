import { Review } from '@/types';
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';

interface ReviewCardProps {
  review: Review;
}

export function ReviewCard({ review }: ReviewCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="border-2 border-black p-6 bg-white"
      style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h4 className="font-bold text-lg">{review.user?.name || 'Anonymous'}</h4>
          <p className="text-sm text-gray-600">
            {new Date(review.createdAt).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
        </div>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`w-5 h-5 ${
                star <= review.rating
                  ? 'fill-amber-400 text-amber-400'
                  : 'text-gray-300'
              }`}
            />
          ))}
        </div>
      </div>
      {review.comment && (
        <p className="text-gray-800 leading-relaxed">{review.comment}</p>
      )}
    </motion.div>
  );
}
