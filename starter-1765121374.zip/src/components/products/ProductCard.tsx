import { Link } from 'react-router-dom';
import { Product } from '@/types';
import { Clock, Zap, Star, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

interface ProductCardProps {
  product: Product;
  index?: number;
  viewMode?: 'grid' | 'list';
}

export function ProductCard({ product, index = 0, viewMode = 'grid' }: ProductCardProps) {
  const discount = Math.round((1 - product.price / product.originalPrice) * 100);

  if (viewMode === 'list') {
    return (
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, delay: index * 0.05 }}
      >
        <Link to={`/products/${product.id}`}>
          <div className="group bg-white border-2 border-black shadow-brutalist hover:shadow-brutalist-lg transition-all duration-200 overflow-hidden">
            <div className="flex flex-col sm:flex-row">
              {/* Image */}
              <div className="relative w-full sm:w-48 h-48 sm:h-32 overflow-hidden flex-shrink-0">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 right-2 bg-[#0A7A7A] text-white px-2 py-1 border-2 border-black font-bold text-xs">
                  {discount}% OFF
                </div>
                <div className="absolute top-2 left-2 bg-white text-black px-2 py-1 border-2 border-black font-medium text-xs uppercase">
                  {product.category}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between h-full">
                  <div className="flex-1 mb-4 sm:mb-0 sm:pr-6">
                    <h3 className="font-display font-bold text-xl mb-2 group-hover:text-[#0A7A7A] transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {product.description}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{product.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Zap className="h-3 w-3" />
                        <span>{product.deliveryTime}</span>
                      </div>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="text-right">
                    <span className="text-gray-400 line-through text-sm">₹{product.originalPrice}</span>
                    <div className="font-display font-bold text-2xl text-[#0A7A7A]">
                      ₹{product.price}
                    </div>
                    <div className="bg-black text-white px-3 py-1 font-medium text-sm group-hover:bg-[#0A7A7A] transition-colors mt-2">
                      View Details →
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link to={`/products/${product.id}`}>
        <div className="group bg-white border-2 border-black shadow-brutalist hover:shadow-brutalist-lg transition-all duration-200 overflow-hidden relative">
          {/* Trending Badge */}
          {discount > 70 && (
            <div className="absolute top-0 left-0 bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 text-xs font-bold z-10 border-b-2 border-r-2 border-black">
              <TrendingUp className="h-3 w-3 inline mr-1" />
              HOT DEAL
            </div>
          )}
          
          {/* Image */}
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            {/* Discount Badge */}
            <div className="absolute top-2 sm:top-3 right-2 sm:right-3 bg-[#0A7A7A] text-white px-2 sm:px-3 py-0.5 sm:py-1 border-2 border-black font-bold text-xs sm:text-sm shadow-lg">
              {discount}% OFF
            </div>
            {/* Category Badge */}
            <div className="absolute top-2 sm:top-3 left-2 sm:left-3 bg-white text-black px-2 sm:px-3 py-0.5 sm:py-1 border-2 border-black font-medium text-xs uppercase tracking-wider">
              {product.category}
            </div>
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>

          {/* Content */}
          <div className="p-3 sm:p-4 md:p-5">
            <h3 className="font-display font-bold text-base sm:text-lg md:text-xl mb-2 group-hover:text-[#0A7A7A] transition-colors line-clamp-2">
              {product.name}
            </h3>
            <p className="text-gray-600 text-xs sm:text-sm mb-3 sm:mb-4 line-clamp-2">
              {product.description}
            </p>

            {/* Meta Info */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-3 sm:mb-4 text-xs sm:text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="truncate">{product.duration}</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                <span className="truncate">{product.deliveryTime}</span>
              </div>
            </div>

            {/* Price */}
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
              <div className="flex-1">
                <span className="text-gray-400 line-through text-xs sm:text-sm">₹{product.originalPrice}</span>
                <div className="font-display font-bold text-lg sm:text-xl md:text-2xl text-[#0A7A7A]">
                  ₹{product.price}
                </div>
                <div className="text-xs text-emerald-600 font-medium">
                  Save ₹{product.originalPrice - product.price}
                </div>
              </div>
              <div className="bg-black text-white px-3 sm:px-4 py-2 sm:py-1.5 font-medium text-xs sm:text-sm group-hover:bg-[#0A7A7A] transition-colors text-center sm:text-left whitespace-nowrap">
                View Details →
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
