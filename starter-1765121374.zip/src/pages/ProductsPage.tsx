import { useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { useOrders } from '@/contexts/OrderContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Filter, Grid, List, SlidersHorizontal } from 'lucide-react';
import { motion } from 'framer-motion';

const categories = ['All', 'Design', 'Professional', 'Entertainment'];
const sortOptions = [
  { value: 'name', label: 'Name' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'discount', label: 'Highest Discount' }
];

export function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('name');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { products, loading } = useOrders();

  const filteredProducts = products
    .filter(p => selectedCategory === 'All' || p.category === selectedCategory)
    .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                 p.description.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'discount':
          const discountA = ((a.originalPrice - a.price) / a.originalPrice) * 100;
          const discountB = ((b.originalPrice - b.price) / b.originalPrice) * 100;
          return discountB - discountA;
        default:
          return a.name.localeCompare(b.name);
      }
    });

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-[#FAFAF8] to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8 sm:mb-12"
          >
            <h1 className="font-display font-bold text-3xl sm:text-4xl md:text-6xl mb-4 bg-gradient-to-r from-[#0A7A7A] to-[#0FAFAF] bg-clip-text text-transparent">
              Premium Products
            </h1>
            <p className="text-gray-600 text-base sm:text-lg max-w-2xl mx-auto">
              Discover our complete collection of premium digital subscriptions at unbeatable prices
            </p>
            <div className="mt-6 flex items-center justify-center gap-2 text-sm text-gray-500">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span>{products.length} products available</span>
            </div>
          </motion.div>

          {/* Search and Filters */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white border-2 border-black shadow-brutalist-lg p-4 sm:p-6 mb-8"
          >
            {/* Search Bar */}
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border-2 border-gray-300 focus:border-[#0A7A7A] h-12 text-base"
              />
            </div>

            {/* Filters Row */}
            <div className="flex flex-col gap-4">
              {/* Category Filters */}
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className={`border-2 border-black transition-all text-xs sm:text-sm ${
                      selectedCategory === category 
                        ? 'bg-[#0A7A7A] text-white shadow-brutalist hover:shadow-none' 
                        : 'bg-white hover:bg-gray-50 hover:shadow-brutalist'
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              {/* Sort and View Controls */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:justify-between">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full sm:w-auto border-2 border-black px-3 py-2 bg-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#0A7A7A]"
                >
                  {sortOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                
                <div className="flex border-2 border-black bg-white">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className={`border-none rounded-none px-3 py-2 ${viewMode === 'grid' ? 'bg-[#0A7A7A] text-white' : ''}`}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className={`border-none rounded-none px-3 py-2 ${viewMode === 'list' ? 'bg-[#0A7A7A] text-white' : ''}`}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Results Count */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mb-6"
          >
            <p className="text-gray-600 text-sm">
              Showing {filteredProducts.length} of {products.length} products
              {searchQuery && ` for "${searchQuery}"`}
              {selectedCategory !== 'All' && ` in ${selectedCategory}`}
            </p>
          </motion.div>

          {/* Products */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            {loading ? (
              <div className="py-20 text-center">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-[#0A7A7A] border-t-transparent rounded-full animate-spin mx-auto mb-6" />
                  <div className="absolute inset-0 w-16 h-16 border-4 border-[#0FAFAF] border-b-transparent rounded-full animate-spin mx-auto" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
                </div>
                <h3 className="font-display font-bold text-xl mb-2">Loading Premium Products</h3>
                <p className="text-gray-600">Fetching the best deals for you...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="py-20 text-center">
                <div className="w-24 h-24 bg-gray-100 border-2 border-black mx-auto mb-6 flex items-center justify-center">
                  <Search className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="font-display font-bold text-xl mb-2">No Products Found</h3>
                <p className="text-gray-600 mb-6">
                  {searchQuery 
                    ? `No products match "${searchQuery}"`
                    : `No products available in ${selectedCategory}`
                  }
                </p>
                <Button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                  }}
                  className="bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none"
                >
                  Clear Filters
                </Button>
              </div>
            ) : (
              <ProductGrid products={filteredProducts} viewMode={viewMode} />
            )}
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
