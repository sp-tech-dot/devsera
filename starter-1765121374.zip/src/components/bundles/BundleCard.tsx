import { Link } from 'react-router-dom';
import { Bundle } from '@/types';
import { Clock, Zap, Package } from 'lucide-react';
import { motion } from 'framer-motion';

interface BundleCardProps {
  bundle: Bundle;
  index?: number;
}

export function BundleCard({ bundle, index = 0 }: BundleCardProps) {
  const discountPercentage = Math.round(
    ((bundle.originalPrice - bundle.price) / bundle.originalPrice) * 100
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ scale: 1.02 }}
      className="group"
    >
      <Link to={`/bundles/${bundle.slug}`}>
        <div
          className="border-2 border-black bg-white overflow-hidden transition-all hover:translate-x-1 hover:translate-y-1"
          style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
        >
          {/* Bundle Badge */}
          <div className="relative">
            <img
              src={bundle.imageUrl || 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800&q=80'}
              alt={bundle.name}
              className="w-full h-48 object-cover"
            />
            <div className="absolute top-4 left-4 bg-[#EF4444] text-white px-4 py-2 border-2 border-black font-bold uppercase text-sm"
              style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.3)' }}
            >
              <Package className="w-4 h-4 inline mr-1" />
              Bundle Deal
            </div>
            {discountPercentage > 0 && (
              <div className="absolute top-4 right-4 bg-[#F59E0B] text-white px-4 py-2 border-2 border-black font-bold text-lg"
                style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.3)' }}
              >
                {discountPercentage}% OFF
              </div>
            )}
          </div>

          <div className="p-6">
            <h3 className="font-bold text-2xl mb-2 group-hover:text-[#0A7A7A] transition-colors">
              {bundle.name}
            </h3>
            <p className="text-gray-600 mb-4 line-clamp-2">{bundle.description}</p>

            {/* Products in bundle */}
            <div className="mb-4 flex flex-wrap gap-2">
              {bundle.products?.slice(0, 3).map((product) => (
                <span
                  key={product.id}
                  className="text-xs bg-gray-100 px-2 py-1 border border-gray-300 uppercase tracking-wide"
                >
                  {product.name}
                </span>
              ))}
              {bundle.products?.length > 3 && (
                <span className="text-xs bg-gray-100 px-2 py-1 border border-gray-300 uppercase tracking-wide">
                  +{bundle.products.length - 3} more
                </span>
              )}
            </div>

            <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>{bundle.deliveryTime}</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap className="w-4 h-4" />
                <span>{bundle.durationDays} days</span>
              </div>
            </div>

            <div className="flex items-end justify-between">
              <div>
                <div className="text-sm text-gray-500 line-through">
                  ₹{bundle.originalPrice}
                </div>
                <div className="text-3xl font-bold text-[#0A7A7A]">
                  ₹{bundle.price}
                </div>
              </div>
              <button className="bg-[#0A7A7A] text-white px-6 py-3 border-2 border-black font-bold uppercase text-sm hover:bg-[#085858] transition-colors"
                style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
              >
                View Bundle
              </button>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
