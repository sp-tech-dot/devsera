// Product Types
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice: number;
  duration: string;
  deliveryTime: string;
  category: string;
  image: string;
  features: string[];
  rules: string[];
  refundPolicy: string;
  available: boolean;
}

// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  whatsapp?: string;
  telegram?: string;
  isAdmin: boolean;
  createdAt: string;
}

// Order Types
export type OrderStatus = 'pending' | 'submitted' | 'completed' | 'cancelled';

export interface OrderStatusLog {
  status: OrderStatus;
  timestamp: string;
  actor: string;
  note?: string;
}

export interface Order {
  id: string;
  userId: string;
  productId: string;
  product: Product;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  paymentScreenshot?: string;
  statusLogs: OrderStatusLog[];
  credentials?: {
    email: string;
    password: string;
    platformLink: string;
    expiryDate: string;
  };
  cancellationReason?: string;
}

// Account Pool Types
export interface AccountPool {
  id: string;
  productId: string;
  email: string;
  password: string;
  platformLink: string;
  expiryDate: string;
  status: 'available' | 'assigned' | 'blocked';
  assignedOrderId?: string;
}

// Auth Context Types
export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => void;
}

export interface RegisterData {
  email: string;
  password: string;
  name: string;
  whatsapp?: string;
  telegram?: string;
}

// Review Types
export interface Review {
  id: string;
  productId: string;
  userId: string;
  orderId?: string;
  rating: number;
  comment?: string;
  createdAt: string;
  updatedAt: string;
  user?: {
    name: string;
    email: string;
  };
}

// Bundle Types
export interface Bundle {
  id: string;
  name: string;
  slug: string;
  description: string;
  imageUrl: string;
  originalPrice: number;
  price: number;
  discountPercentage: number;
  durationDays: number;
  deliveryTime: string;
  features: string[];
  rules: string[];
  refundPolicy: string;
  available: boolean;
  products: Product[];
  createdAt: string;
}

// Community Types
export interface CommunityPost {
  id: string;
  title: string;
  content: string;
  authorId: string;
  author?: {
    name: string;
    email: string;
    isAdmin: boolean;
  };
  imageUrl?: string;
  pinned: boolean;
  published: boolean;
  createdAt: string;
  updatedAt: string;
  comments?: CommunityComment[];
  reactions?: CommunityReaction[];
  reactionCounts?: {
    like: number;
    love: number;
    fire: number;
    clap: number;
  };
}

export interface CommunityComment {
  id: string;
  postId: string;
  userId: string;
  user?: {
    name: string;
    email: string;
  };
  content: string;
  createdAt: string;
  updatedAt: string;
}

export type ReactionType = 'like' | 'love' | 'fire' | 'clap';

export interface CommunityReaction {
  id: string;
  postId: string;
  userId: string;
  reactionType: ReactionType;
  createdAt: string;
}
