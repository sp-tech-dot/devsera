import { useParams, useNavigate, Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Copy, 
  Check, 
  ExternalLink, 
  MessageCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import { useState } from 'react';

export function OrderDetailPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { getOrderById } = useOrders();
  const { isAuthenticated } = useAuth();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  const order = orderId ? getOrderById(orderId) : undefined;

  if (!order) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="font-display font-bold text-3xl mb-4">Order Not Found</h1>
          <Button onClick={() => navigate('/orders')}>View My Orders</Button>
        </div>
      </Layout>
    );
  }

  const handleCopy = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/orders')}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Orders</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Order ID</p>
                  <p className="font-mono font-bold text-lg">{order.id}</p>
                </div>
                <StatusBadge status={order.status} />
              </div>
              
              <div className="flex items-center gap-4 pt-4 border-t border-gray-200">
                <img 
                  src={order.product.image} 
                  alt={order.product.name}
                  className="w-20 h-20 object-cover border-2 border-black"
                />
                <div className="flex-1">
                  <h2 className="font-display font-bold text-xl">{order.product.name}</h2>
                  <p className="text-gray-600">{order.product.duration}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold text-2xl text-[#0A7A7A]">
                    ₹{order.product.price}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Credentials Section (Completed Orders) */}
            {order.status === 'completed' && order.credentials && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-emerald-50 border-2 border-emerald-500 p-6"
              >
                <h3 className="font-display font-bold text-xl mb-4 text-emerald-800">
                  Your Credentials
                </h3>
                <div className="space-y-4">
                  {/* Email */}
                  <div className="flex items-center justify-between bg-white p-3 border-2 border-emerald-200">
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-wider">Email</p>
                      <p className="font-mono font-medium">{order.credentials.email}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleCopy(order.credentials!.email, 'email')}
                    >
                      {copiedField === 'email' ? (
                        <Check className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>

                  {/* Password */}
                  <div className="flex items-center justify-between bg-white p-3 border-2 border-emerald-200">
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-wider">Password</p>
                      <p className="font-mono font-medium">{order.credentials.password}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleCopy(order.credentials!.password, 'password')}
                    >
                      {copiedField === 'password' ? (
                        <Check className="h-4 w-4 text-emerald-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>

                  {/* Platform Link */}
                  <a
                    href={order.credentials.platformLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between bg-white p-3 border-2 border-emerald-200 hover:bg-emerald-50 transition-colors"
                  >
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-wider">Platform</p>
                      <p className="font-medium text-[#0A7A7A]">{order.credentials.platformLink}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                  </a>

                  {/* Expiry Date */}
                  <div className="bg-amber-50 p-3 border-2 border-amber-200">
                    <p className="text-xs text-gray-500 uppercase tracking-wider">Expires On</p>
                    <p className="font-medium text-amber-700">
                      {format(new Date(order.credentials.expiryDate), 'MMMM d, yyyy')}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Cancellation Reason */}
            {order.status === 'cancelled' && order.cancellationReason && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-red-50 border-2 border-red-300 p-6"
              >
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h3 className="font-display font-bold text-lg text-red-800 mb-2">
                      Order Cancelled
                    </h3>
                    <p className="text-red-700">{order.cancellationReason}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Pending Payment Action */}
            {order.status === 'pending' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-amber-50 border-2 border-amber-300 p-6"
              >
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-display font-bold text-lg text-amber-800 mb-2">
                      Payment Pending
                    </h3>
                    <p className="text-amber-700 mb-4">
                      Complete your payment to proceed with this order.
                    </p>
                    <Link to={`/payment/${order.id}`}>
                      <Button className="bg-amber-500 hover:bg-amber-600 text-white border-2 border-black shadow-brutalist">
                        Complete Payment
                      </Button>
                    </Link>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Payment Screenshot */}
            {order.paymentScreenshot && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white border-2 border-black shadow-brutalist p-6"
              >
                <h3 className="font-display font-bold text-lg mb-4">Payment Screenshot</h3>
                <img 
                  src={order.paymentScreenshot} 
                  alt="Payment screenshot"
                  className="max-w-full max-h-64 object-contain border-2 border-gray-200"
                />
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Order Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <h3 className="font-display font-bold text-lg mb-6">Order Timeline</h3>
              <div className="space-y-0">
                {order.statusLogs.map((log, index) => (
                  <div key={index} className="relative pl-8 pb-6 last:pb-0">
                    {/* Connecting Line */}
                    {index < order.statusLogs.length - 1 && (
                      <div className="absolute left-[11px] top-6 w-0.5 h-full bg-gray-200" />
                    )}
                    {/* Node */}
                    <div className={`absolute left-0 top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      log.status === 'completed' ? 'bg-emerald-500 border-emerald-600' :
                      log.status === 'cancelled' ? 'bg-red-500 border-red-600' :
                      log.status === 'submitted' ? 'bg-blue-500 border-blue-600' :
                      'bg-amber-500 border-amber-600'
                    }`}>
                      <Check className="h-3 w-3 text-white" />
                    </div>
                    {/* Content */}
                    <div>
                      <p className="font-medium capitalize">{log.status}</p>
                      <p className="text-xs text-gray-500 uppercase tracking-wider mt-1">
                        {format(new Date(log.timestamp), 'MMM d, yyyy • h:mm a')}
                      </p>
                      {log.note && (
                        <p className="text-sm text-gray-600 mt-1">{log.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Support */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <h3 className="font-display font-bold text-lg mb-4">Need Help?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Having issues with your order? Contact our support team.
              </p>
              <a
                href="https://t.me/devserastore"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Contact Support
                </Button>
              </a>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
