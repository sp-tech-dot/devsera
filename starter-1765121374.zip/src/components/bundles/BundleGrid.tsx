import { Bundle } from '@/types';
import { BundleCard } from './BundleCard';

interface BundleGridProps {
  bundles: Bundle[];
  title?: string;
  subtitle?: string;
}

export function BundleGrid({ bundles, title, subtitle }: BundleGridProps) {
  return (
    <section className="py-16">
      {(title || subtitle) && (
        <div className="text-center mb-12">
          {title && (
            <h2 className="text-5xl font-bold mb-4">{title}</h2>
          )}
          {subtitle && (
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">{subtitle}</p>
          )}
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {bundles.map((bundle, index) => (
          <BundleCard key={bundle.id} bundle={bundle} index={index} />
        ))}
      </div>
    </section>
  );
}
