import { Product, Order, User, AccountPool } from '@/types';

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Canva Pro',
    description: 'Access premium templates, brand kits, and advanced design tools. Perfect for creators and businesses.',
    price: 149,
    originalPrice: 999,
    duration: '1 Month',
    deliveryTime: '2-4 hours',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400&q=80',
    features: [
      'Unlimited premium templates',
      'Brand Kit access',
      'Background remover',
      'Magic resize',
      '100GB cloud storage',
      'Schedule social media posts'
    ],
    rules: [
      'Do not change account password',
      'Do not share credentials with others',
      'Personal use only'
    ],
    refundPolicy: 'Full refund within 24 hours if account not delivered. No refund after credentials shared.',
    available: true
  },
  {
    id: '2',
    name: 'LinkedIn Premium',
    description: 'Unlock InMail credits, see who viewed your profile, and access LinkedIn Learning courses.',
    price: 299,
    originalPrice: 1999,
    duration: '1 Month',
    deliveryTime: '4-8 hours',
    category: 'Professional',
    image: 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?w=400&q=80',
    features: [
      '15 InMail credits/month',
      'See all profile viewers',
      'LinkedIn Learning access',
      'Salary insights',
      'Applicant insights',
      'Open Profile visibility'
    ],
    rules: [
      'Do not change account settings',
      'Do not send spam messages',
      'Professional use only'
    ],
    refundPolicy: 'Full refund within 24 hours if account not delivered.',
    available: true
  },
  {
    id: '3',
    name: 'Netflix Premium',
    description: 'Watch unlimited movies and TV shows in 4K Ultra HD on up to 4 screens simultaneously.',
    price: 99,
    originalPrice: 649,
    duration: '1 Month',
    deliveryTime: '1-2 hours',
    category: 'Entertainment',
    image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&q=80',
    features: [
      '4K Ultra HD streaming',
      'Watch on 4 screens',
      'Download on 6 devices',
      'Ad-free experience',
      'All content library access'
    ],
    rules: [
      'Do not change profile name',
      'Do not create new profiles',
      'Do not change password'
    ],
    refundPolicy: 'Full refund within 12 hours if account not working.',
    available: true
  },
  {
    id: '4',
    name: 'Spotify Premium',
    description: 'Ad-free music streaming with offline downloads and unlimited skips.',
    price: 59,
    originalPrice: 119,
    duration: '1 Month',
    deliveryTime: '1-2 hours',
    category: 'Entertainment',
    image: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=400&q=80',
    features: [
      'Ad-free listening',
      'Offline downloads',
      'Unlimited skips',
      'High quality audio',
      'Play any song'
    ],
    rules: [
      'Do not change account region',
      'Do not link to other services',
      'Personal use only'
    ],
    refundPolicy: 'Full refund within 24 hours if account not delivered.',
    available: true
  },
  {
    id: '5',
    name: 'Adobe Creative Cloud',
    description: 'Full access to Photoshop, Illustrator, Premiere Pro, and 20+ creative apps.',
    price: 499,
    originalPrice: 4999,
    duration: '1 Month',
    deliveryTime: '6-12 hours',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=400&q=80',
    features: [
      'Photoshop',
      'Illustrator',
      'Premiere Pro',
      'After Effects',
      '100GB cloud storage',
      'Adobe Fonts'
    ],
    rules: [
      'Do not install on more than 2 devices',
      'Do not change account password',
      'Do not share credentials'
    ],
    refundPolicy: 'Full refund within 48 hours if account not delivered.',
    available: true
  },
  {
    id: '6',
    name: 'YouTube Premium',
    description: 'Ad-free videos, background play, and YouTube Music Premium included.',
    price: 79,
    originalPrice: 159,
    duration: '1 Month',
    deliveryTime: '2-4 hours',
    category: 'Entertainment',
    image: 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=400&q=80',
    features: [
      'Ad-free videos',
      'Background play',
      'YouTube Music Premium',
      'Download videos',
      'YouTube Originals'
    ],
    rules: [
      'Do not change account settings',
      'Do not link to TV apps',
      'Personal use only'
    ],
    refundPolicy: 'Full refund within 24 hours if account not delivered.',
    available: true
  }
];

export const mockUser: User = {
  id: 'user-1',
  email: 'john@example.com',
  name: 'John Doe',
  whatsapp: '+91 98765 43210',
  telegram: '@johndoe',
  isAdmin: false,
  createdAt: '2024-01-15T10:00:00Z'
};

export const mockAdminUser: User = {
  id: 'admin-1',
  email: 'admin@devsera.store',
  name: 'Admin User',
  isAdmin: true,
  createdAt: '2024-01-01T00:00:00Z'
};

export const mockOrders: Order[] = [
  {
    id: 'ORD-2024-001',
    userId: 'user-1',
    productId: '1',
    product: mockProducts[0],
    status: 'completed',
    createdAt: '2024-01-20T14:30:00Z',
    updatedAt: '2024-01-20T16:45:00Z',
    paymentScreenshot: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80',
    statusLogs: [
      { status: 'pending', timestamp: '2024-01-20T14:30:00Z', actor: 'system', note: 'Order created' },
      { status: 'submitted', timestamp: '2024-01-20T14:35:00Z', actor: 'user-1', note: 'Payment screenshot uploaded' },
      { status: 'completed', timestamp: '2024-01-20T16:45:00Z', actor: 'admin-1', note: 'Payment verified, credentials assigned' }
    ],
    credentials: {
      email: 'canva.shared.001@gmail.com',
      password: 'SecurePass123!',
      platformLink: 'https://canva.com',
      expiryDate: '2024-02-20'
    }
  },
  {
    id: 'ORD-2024-002',
    userId: 'user-1',
    productId: '3',
    product: mockProducts[2],
    status: 'submitted',
    createdAt: '2024-01-22T09:15:00Z',
    updatedAt: '2024-01-22T09:20:00Z',
    paymentScreenshot: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80',
    statusLogs: [
      { status: 'pending', timestamp: '2024-01-22T09:15:00Z', actor: 'system', note: 'Order created' },
      { status: 'submitted', timestamp: '2024-01-22T09:20:00Z', actor: 'user-1', note: 'Payment screenshot uploaded' }
    ]
  },
  {
    id: 'ORD-2024-003',
    userId: 'user-1',
    productId: '2',
    product: mockProducts[1],
    status: 'pending',
    createdAt: '2024-01-23T11:00:00Z',
    updatedAt: '2024-01-23T11:00:00Z',
    statusLogs: [
      { status: 'pending', timestamp: '2024-01-23T11:00:00Z', actor: 'system', note: 'Order created' }
    ]
  },
  {
    id: 'ORD-2024-004',
    userId: 'user-1',
    productId: '4',
    product: mockProducts[3],
    status: 'cancelled',
    createdAt: '2024-01-18T16:00:00Z',
    updatedAt: '2024-01-19T10:00:00Z',
    paymentScreenshot: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&q=80',
    statusLogs: [
      { status: 'pending', timestamp: '2024-01-18T16:00:00Z', actor: 'system', note: 'Order created' },
      { status: 'submitted', timestamp: '2024-01-18T16:10:00Z', actor: 'user-1', note: 'Payment screenshot uploaded' },
      { status: 'cancelled', timestamp: '2024-01-19T10:00:00Z', actor: 'admin-1', note: 'Payment verification failed' }
    ],
    cancellationReason: 'Payment screenshot unclear. Transaction ID not visible. Please create a new order with a clear screenshot.'
  }
];

export const mockAccountPool: AccountPool[] = [
  {
    id: 'acc-1',
    productId: '1',
    email: 'canva.shared.001@gmail.com',
    password: 'SecurePass123!',
    platformLink: 'https://canva.com',
    expiryDate: '2024-03-15',
    status: 'assigned',
    assignedOrderId: 'ORD-2024-001'
  },
  {
    id: 'acc-2',
    productId: '1',
    email: 'canva.shared.002@gmail.com',
    password: 'SecurePass456!',
    platformLink: 'https://canva.com',
    expiryDate: '2024-03-20',
    status: 'available'
  },
  {
    id: 'acc-3',
    productId: '3',
    email: 'netflix.shared.001@gmail.com',
    password: 'NetflixPass789!',
    platformLink: 'https://netflix.com',
    expiryDate: '2024-02-28',
    status: 'available'
  },
  {
    id: 'acc-4',
    productId: '2',
    email: 'linkedin.shared.001@gmail.com',
    password: 'LinkedInPass321!',
    platformLink: 'https://linkedin.com',
    expiryDate: '2024-02-15',
    status: 'blocked'
  }
];
