CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT NOT NULL,
  whatsapp TEXT,
  telegram TEXT,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price INTEGER NOT NULL,
  original_price INTEGER NOT NULL,
  duration TEXT NOT NULL,
  delivery_time TEXT NOT NULL,
  category TEXT NOT NULL,
  image TEXT NOT NULL,
  features TEXT[] DEFAULT '{}',
  rules TEXT[] DEFAULT '{}',
  refund_policy TEXT NOT NULL,
  available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'submitted', 'completed', 'cancelled')),
  payment_screenshot TEXT,
  cancellation_reason TEXT,
  credential_email TEXT,
  credential_password TEXT,
  credential_platform_link TEXT,
  credential_expiry_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_status_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  actor TEXT NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS account_pool (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  platform_link TEXT NOT NULL,
  expiry_date TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'assigned', 'blocked')),
  assigned_order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  value TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_order_status_logs_order_id ON order_status_logs(order_id);
CREATE INDEX IF NOT EXISTS idx_account_pool_product_id ON account_pool(product_id);
CREATE INDEX IF NOT EXISTS idx_account_pool_status ON account_pool(status);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS products_updated_at ON products;
CREATE TRIGGER products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS orders_updated_at ON orders;
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS account_pool_updated_at ON account_pool;
CREATE TRIGGER account_pool_updated_at BEFORE UPDATE ON account_pool FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS settings_updated_at ON settings;
CREATE TRIGGER settings_updated_at BEFORE UPDATE ON settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, name, is_admin)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE((NEW.raw_user_meta_data->>'is_admin')::boolean, false)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

INSERT INTO settings (key, value) VALUES 
  ('upi_id', 'devsera@upi'),
  ('qr_code_image', ''),
  ('telegram_link', 'https://t.me/devserastore'),
  ('telegram_community_link', 'https://t.me/devseracommunity'),
  ('whatsapp_support', '+91 98765 43210')
ON CONFLICT (key) DO NOTHING;

INSERT INTO products (name, description, price, original_price, duration, delivery_time, category, image, features, rules, refund_policy, available) VALUES
  ('Canva Pro', 'Access premium templates, brand kits, and advanced design tools. Perfect for creators and businesses.', 149, 999, '1 Month', '2-4 hours', 'Design', 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400&q=80', ARRAY['Unlimited premium templates', 'Brand Kit access', 'Background remover', 'Magic resize', '100GB cloud storage', 'Schedule social media posts'], ARRAY['Do not change account password', 'Do not share credentials with others', 'Personal use only'], 'Full refund within 24 hours if account not delivered. No refund after credentials shared.', true),
  ('LinkedIn Premium', 'Unlock InMail credits, see who viewed your profile, and access LinkedIn Learning courses.', 299, 1999, '1 Month', '4-8 hours', 'Professional', 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?w=400&q=80', ARRAY['15 InMail credits/month', 'See all profile viewers', 'LinkedIn Learning access', 'Salary insights', 'Applicant insights', 'Open Profile visibility'], ARRAY['Do not change account settings', 'Do not send spam messages', 'Professional use only'], 'Full refund within 24 hours if account not delivered.', true),
  ('Netflix Premium', 'Watch unlimited movies and TV shows in 4K Ultra HD on up to 4 screens simultaneously.', 99, 649, '1 Month', '1-2 hours', 'Entertainment', 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&q=80', ARRAY['4K Ultra HD streaming', 'Watch on 4 screens', 'Download on 6 devices', 'Ad-free experience', 'All content library access'], ARRAY['Do not change profile name', 'Do not create new profiles', 'Do not change password'], 'Full refund within 12 hours if account not working.', true),
  ('Spotify Premium', 'Ad-free music streaming with offline downloads and unlimited skips.', 59, 119, '1 Month', '1-2 hours', 'Entertainment', 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=400&q=80', ARRAY['Ad-free listening', 'Offline downloads', 'Unlimited skips', 'High quality audio', 'Play any song'], ARRAY['Do not change account region', 'Do not link to other services', 'Personal use only'], 'Full refund within 24 hours if account not delivered.', true),
  ('Adobe Creative Cloud', 'Full access to Photoshop, Illustrator, Premiere Pro, and 20+ creative apps.', 499, 4999, '1 Month', '6-12 hours', 'Design', 'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=400&q=80', ARRAY['All Adobe apps access', 'Cloud storage', 'Adobe Fonts', 'Adobe Portfolio', 'Behance integration'], ARRAY['Do not change account email', 'Do not share credentials', 'Creative use only'], 'Full refund within 48 hours if account not delivered.', true),
  ('YouTube Premium', 'Ad-free videos, background play, and YouTube Music Premium included.', 79, 129, '1 Month', '1-2 hours', 'Entertainment', 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=400&q=80', ARRAY['Ad-free videos', 'Background play', 'YouTube Music Premium', 'Download videos', 'YouTube Originals'], ARRAY['Do not change account settings', 'Do not share access', 'Personal use only'], 'Full refund within 24 hours if account not delivered.', true)
ON CONFLICT DO NOTHING;
