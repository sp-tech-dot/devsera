import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { 
  DollarSign, 
  Clock, 
  CheckCircle, 
  XCircle,
  ChevronRight,
  Package,
  Users,
  Settings
} from 'lucide-react';

export function AdminDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { orders } = useOrders();

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  // Calculate metrics
  const totalRevenue = orders
    .filter(o => o.status === 'completed')
    .reduce((sum, o) => sum + o.product.price, 0);
  
  const pendingPayments = orders.filter(o => o.status === 'submitted').length;
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const cancelledOrders = orders.filter(o => o.status === 'cancelled').length;

  const recentOrders = orders.slice(0, 5);

  const metrics = [
    {
      label: 'Total Revenue',
      value: `₹${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-emerald-500'
    },
    {
      label: 'Pending Verification',
      value: pendingPayments,
      icon: Clock,
      color: 'bg-blue-500'
    },
    {
      label: 'Completed Orders',
      value: completedOrders,
      icon: CheckCircle,
      color: 'bg-[#0A7A7A]'
    },
    {
      label: 'Cancelled Orders',
      value: cancelledOrders,
      icon: XCircle,
      color: 'bg-red-500'
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display font-bold text-4xl mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage orders, payments, and account pool</p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <div className="flex items-center gap-4">
                <div className={`${metric.color} p-3 text-white`}>
                  <metric.icon className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">{metric.label}</p>
                  <p className="font-display font-bold text-2xl">{metric.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link to="/admin/orders">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white border-2 border-black shadow-brutalist p-6 hover:shadow-brutalist-lg transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-[#0A7A7A] p-3 text-white">
                    <Package className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg">Manage Orders</h3>
                    <p className="text-gray-600 text-sm">View and verify payments</p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </motion.div>
          </Link>

          <Link to="/admin/accounts">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="bg-white border-2 border-black shadow-brutalist p-6 hover:shadow-brutalist-lg transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-[#0A7A7A] p-3 text-white">
                    <Users className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg">Account Pool</h3>
                    <p className="text-gray-600 text-sm">Manage available accounts</p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </motion.div>
          </Link>

          <Link to="/admin/settings">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white border-2 border-black shadow-brutalist p-6 hover:shadow-brutalist-lg transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-[#0A7A7A] p-3 text-white">
                    <Settings className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg">Settings</h3>
                    <p className="text-gray-600 text-sm">Payment & community settings</p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </motion.div>
          </Link>

          <Link to="/admin/community">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="bg-white border-2 border-black shadow-brutalist p-6 hover:shadow-brutalist-lg transition-all"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="bg-[#0A7A7A] p-3 text-white">
                    <Users className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg">Community</h3>
                    <p className="text-gray-600 text-sm">Manage posts & announcements</p>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </motion.div>
          </Link>
        </div>

        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="bg-white border-2 border-black shadow-brutalist"
        >
          <div className="p-6 border-b-2 border-black flex items-center justify-between">
            <h2 className="font-display font-bold text-xl">Recent Orders</h2>
            <Link 
              to="/admin/orders" 
              className="text-[#0A7A7A] font-medium text-sm hover:underline"
            >
              View All →
            </Link>
          </div>
          
          <div className="divide-y-2 divide-black">
            {recentOrders.map(order => (
              <Link 
                key={order.id} 
                to={`/admin/orders/${order.id}`}
                className="block p-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <img 
                    src={order.product.image} 
                    alt={order.product.name}
                    className="w-12 h-12 object-cover border-2 border-black"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-sm">{order.id}</span>
                      <StatusBadge status={order.status} />
                    </div>
                    <p className="text-sm text-gray-600 truncate">
                      {order.product.name}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[#0A7A7A]">₹{order.product.price}</p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(order.createdAt), 'MMM d, h:mm a')}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
