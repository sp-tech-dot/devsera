import { Layout } from '@/components/layout/Layout';
import { motion } from 'framer-motion';

export function RefundPolicyPage() {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mx-auto"
        >
          <h1 className="font-display font-bold text-4xl md:text-5xl mb-8">
            Refund Policy
          </h1>

          <div className="prose prose-lg max-w-none">
            <div className="bg-white border-2 border-black shadow-brutalist p-8 mb-8">
              <h2 className="font-display font-bold text-2xl mb-4">
                When You're Eligible for a Refund
              </h2>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-3">
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>Credentials not delivered within the promised delivery timeframe</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>Credentials don't work within 24 hours of delivery</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>Account gets suspended due to issues on our end (not user violation)</span>
                </li>
              </ul>
            </div>

            <div className="bg-white border-2 border-black shadow-brutalist p-8 mb-8">
              <h2 className="font-display font-bold text-2xl mb-4">
                When Refunds Are Not Applicable
              </h2>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-3">
                  <span className="text-red-500 font-bold">✗</span>
                  <span>After successful credential delivery and verification by user</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 font-bold">✗</span>
                  <span>Account suspended due to user violating usage rules</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 font-bold">✗</span>
                  <span>Sharing credentials with others</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 font-bold">✗</span>
                  <span>Changing account password or settings</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-red-500 font-bold">✗</span>
                  <span>Request made after 24 hours of credential delivery</span>
                </li>
              </ul>
            </div>

            <div className="bg-white border-2 border-black shadow-brutalist p-8 mb-8">
              <h2 className="font-display font-bold text-2xl mb-4">
                How to Request a Refund
              </h2>
              <ol className="space-y-4 text-gray-700">
                <li className="flex items-start gap-3">
                  <span className="bg-[#0A7A7A] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">1</span>
                  <span>Contact us via Telegram @devserastore within 24 hours of the issue</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="bg-[#0A7A7A] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">2</span>
                  <span>Provide your Order ID and describe the issue</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="bg-[#0A7A7A] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">3</span>
                  <span>Include screenshots if applicable</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="bg-[#0A7A7A] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0">4</span>
                  <span>Our team will review and process within 24-48 hours</span>
                </li>
              </ol>
            </div>

            <div className="bg-amber-50 border-2 border-amber-300 p-8">
              <h2 className="font-display font-bold text-2xl mb-4 text-amber-800">
                Important Notes
              </h2>
              <ul className="space-y-2 text-amber-700">
                <li>• Refunds are processed to the original payment method</li>
                <li>• Processing time: 3-5 business days</li>
                <li>• Partial refunds may be offered for partial service periods</li>
                <li>• We reserve the right to deny refunds in case of policy violations</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
