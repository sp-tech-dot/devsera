INSERT INTO settings (key, value) VALUES 
  ('upi_id', 'devsera@upi'),
  ('qr_code_image', ''),
  ('telegram_link', 'https://t.me/devserastore'),
  ('telegram_community_link', 'https://t.me/devseracommunity'),
  ('whatsapp_support', '+91 98765 43210')
ON CONFLICT (key) DO NOTHING;
