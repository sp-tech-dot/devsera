import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { 
  DollarSign, 
  Clock, 
  CheckCircle, 
  XCircle,
  ChevronRight,
  Package,
  Users,
  Settings,
  TrendingUp,
  Activity,
  BarChart3,
  Eye,
  AlertCircle,
  Calendar,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';

export function AdminDashboardNew() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { orders, products } = useOrders();
  const [timeRange, setTimeRange] = useState('7d');

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  // Calculate metrics
  const totalRevenue = orders
    .filter(o => o.status === 'completed')
    .reduce((sum, o) => sum + o.product.price, 0);
  
  const pendingPayments = orders.filter(o => o.status === 'submitted').length;
  const completedOrders = orders.filter(o => o.status === 'completed').length;
  const cancelledOrders = orders.filter(o => o.status === 'cancelled').length;
  const totalOrders = orders.length;

  // Calculate growth (mock data for demo)
  const revenueGrowth = 12.5;
  const orderGrowth = 8.3;
  const conversionRate = totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0;

  const recentOrders = orders.slice(0, 8);

  const metrics = [
    {
      label: 'Total Revenue',
      value: `₹${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'from-emerald-500 to-emerald-600',
      bgColor: 'bg-emerald-50',
      iconColor: 'text-emerald-600',
      growth: revenueGrowth,
      isPositive: true
    },
    {
      label: 'Pending Verification',
      value: pendingPayments,
      icon: Clock,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      growth: null,
      isPositive: null
    },
    {
      label: 'Completed Orders',
      value: completedOrders,
      icon: CheckCircle,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      growth: orderGrowth,
      isPositive: true
    },
    {
      label: 'Conversion Rate',
      value: `${conversionRate.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600',
      growth: 2.1,
      isPositive: true
    }
  ];

  const quickActions = [
    {
      title: 'Manage Orders',
      description: 'Review and process pending orders',
      icon: Package,
      href: '/admin/orders',
      color: 'from-blue-500 to-blue-600',
      count: pendingPayments
    },
    {
      title: 'Account Pool',
      description: 'Manage available accounts',
      icon: Users,
      href: '/admin/accounts',
      color: 'from-green-500 to-green-600',
      count: products.length
    },
    {
      title: 'Community',
      description: 'Manage posts & announcements',
      icon: Activity,
      href: '/admin/community',
      color: 'from-purple-500 to-purple-600',
      count: null
    },
    {
      title: 'Settings',
      description: 'Payment & community settings',
      icon: Settings,
      href: '/admin/settings',
      color: 'from-gray-500 to-gray-600',
      count: null
    }
  ];

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="font-display font-bold text-3xl sm:text-4xl text-gray-900 mb-2">
                  Admin Dashboard
                </h1>
                <p className="text-gray-600">
                  Welcome back, {user.name}. Here's what's happening with your store.
                </p>
              </div>
              <div className="mt-4 sm:mt-0 flex items-center gap-3">
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                </select>
                <Button
                  onClick={() => navigate('/admin/orders')}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  View All Orders
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metrics.map((metric, index) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl border border-gray-200 shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl ${metric.bgColor} flex items-center justify-center`}>
                    <metric.icon className={`h-6 w-6 ${metric.iconColor}`} />
                  </div>
                  {metric.growth !== null && (
                    <div className={`flex items-center gap-1 text-sm font-medium ${
                      metric.isPositive ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {metric.isPositive ? (
                        <ArrowUpRight className="h-4 w-4" />
                      ) : (
                        <ArrowDownRight className="h-4 w-4" />
                      )}
                      {metric.growth}%
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</p>
                  <p className="text-sm text-gray-600">{metric.label}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Quick Actions */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-2xl border border-gray-200 shadow-lg p-6"
              >
                <h3 className="font-bold text-lg text-gray-900 mb-6">Quick Actions</h3>
                <div className="space-y-4">
                  {quickActions.map((action, index) => (
                    <Link
                      key={action.title}
                      to={action.href}
                      className="block group"
                    >
                      <div className="flex items-center p-4 rounded-xl border border-gray-200 hover:border-gray-300 hover:shadow-md transition-all">
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${action.color} flex items-center justify-center mr-4`}>
                          <action.icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                              {action.title}
                            </h4>
                            {action.count !== null && (
                              <span className="bg-red-100 text-red-600 text-xs font-medium px-2 py-1 rounded-full">
                                {action.count}
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 truncate">{action.description}</p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-gray-400 group-hover:text-gray-600 transition-colors" />
                      </div>
                    </Link>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Recent Orders */}
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white rounded-2xl border border-gray-200 shadow-lg p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-bold text-lg text-gray-900">Recent Orders</h3>
                  <Link
                    to="/admin/orders"
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
                  >
                    View All
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </div>

                {recentOrders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No orders yet</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentOrders.map((order, index) => (
                      <motion.div
                        key={order.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 + index * 0.05 }}
                        className="flex items-center p-4 rounded-xl border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all"
                      >
                        <img
                          src={order.product.image}
                          alt={order.product.name}
                          className="w-12 h-12 object-cover rounded-lg border border-gray-200 mr-4"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-medium text-gray-900 truncate">
                              {order.product.name}
                            </h4>
                            <StatusBadge status={order.status} />
                          </div>
                          <div className="flex items-center justify-between text-sm text-gray-600">
                            <span className="truncate">Order #{order.id.slice(0, 8)}...</span>
                            <span className="font-medium text-gray-900">₹{order.product.price}</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">
                            {format(new Date(order.createdAt), 'MMM d, h:mm a')}
                          </p>
                        </div>
                        <Link
                          to={`/admin/orders/${order.id}`}
                          className="ml-4 p-2 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            </div>
          </div>

          {/* Alerts Section */}
          {pendingPayments > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="mt-8 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 p-6"
            >
              <div className="flex items-start gap-4">
                <AlertCircle className="h-6 w-6 text-amber-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="font-semibold text-amber-800 mb-2">
                    Action Required: {pendingPayments} Payment{pendingPayments > 1 ? 's' : ''} Pending Verification
                  </h3>
                  <p className="text-amber-700 text-sm mb-4">
                    You have {pendingPayments} order{pendingPayments > 1 ? 's' : ''} waiting for payment verification. 
                    Review and process them to maintain customer satisfaction.
                  </p>
                  <Button
                    onClick={() => navigate('/admin/orders?status=submitted')}
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                  >
                    Review Pending Orders
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </Layout>
  );
}