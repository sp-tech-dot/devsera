import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, DbAccountPool } from '@/lib/supabase';
import { AccountPool } from '@/types';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Check, 
  X, 
  Loader2,
  AlertCircle
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export function AdminOrderDetailPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { getOrderById, approveOrder, rejectOrder } = useOrders();
  const { user, isAuthenticated } = useAuth();
  
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [accountPool, setAccountPool] = useState<AccountPool[]>([]);
  const [credentials, setCredentials] = useState({
    email: '',
    password: '',
    platformLink: '',
    expiryDate: ''
  });
  const [processing, setProcessing] = useState(false);

  // Fetch available accounts from Supabase
  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const { data, error } = await supabase
          .from('account_pool')
          .select('*')
          .eq('status', 'available');

        if (error) throw error;

        const mappedAccounts: AccountPool[] = (data || []).map((acc: DbAccountPool) => ({
          id: acc.id,
          productId: acc.product_id,
          email: acc.email,
          password: acc.password,
          platformLink: acc.platform_link,
          expiryDate: acc.expiry_date,
          status: acc.status
        }));

        setAccountPool(mappedAccounts);
      } catch (error) {
        console.error('Error fetching accounts:', error);
      }
    };

    fetchAccounts();
  }, []);

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  const order = orderId ? getOrderById(orderId) : undefined;

  if (!order) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="font-display font-bold text-3xl mb-4">Order Not Found</h1>
          <Button onClick={() => navigate('/admin/orders')}>Back to Orders</Button>
        </div>
      </Layout>
    );
  }

  // Get available accounts for this product
  const availableAccounts = accountPool.filter(
    acc => acc.productId === order.productId && acc.status === 'available'
  );

  const handleSelectAccount = (accountId: string) => {
    const account = availableAccounts.find(a => a.id === accountId);
    if (account) {
      setCredentials({
        email: account.email,
        password: account.password,
        platformLink: account.platformLink,
        expiryDate: account.expiryDate
      });
    }
  };

  const handleApprove = async () => {
    if (!credentials.email || !credentials.password || !credentials.platformLink || !credentials.expiryDate) {
      return;
    }
    
    setProcessing(true);
    try {
      await approveOrder(order.id, credentials);
      
      // Mark the account as assigned if it was selected from pool
      const selectedAccount = availableAccounts.find(a => a.email === credentials.email);
      if (selectedAccount) {
        await supabase
          .from('account_pool')
          .update({ status: 'assigned', assigned_order_id: order.id })
          .eq('id', selectedAccount.id);
      }
      
      setShowApproveDialog(false);
      navigate('/admin/orders');
    } catch (error: any) {
      console.error('Error approving order:', error);
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) return;
    
    setProcessing(true);
    try {
      await rejectOrder(order.id, rejectionReason);
      setShowRejectDialog(false);
      navigate('/admin/orders');
    } catch (error: any) {
      console.error('Error rejecting order:', error);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/admin/orders')}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Orders</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Order ID</p>
                  <p className="font-mono font-bold text-lg">{order.id}</p>
                </div>
                <StatusBadge status={order.status} />
              </div>
              
              <div className="flex items-center gap-4 pt-4 border-t border-gray-200">
                <img 
                  src={order.product.image} 
                  alt={order.product.name}
                  className="w-20 h-20 object-cover border-2 border-black"
                />
                <div className="flex-1">
                  <h2 className="font-display font-bold text-xl">{order.product.name}</h2>
                  <p className="text-gray-600">{order.product.duration}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold text-2xl text-[#0A7A7A]">
                    ₹{order.product.price}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Payment Screenshot */}
            {order.paymentScreenshot && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white border-2 border-black shadow-brutalist p-6"
              >
                <h3 className="font-display font-bold text-lg mb-4">Payment Screenshot</h3>
                <img 
                  src={order.paymentScreenshot} 
                  alt="Payment screenshot"
                  className="max-w-full max-h-96 object-contain border-2 border-gray-200 mx-auto"
                />
              </motion.div>
            )}

            {/* Admin Actions */}
            {order.status === 'submitted' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-blue-50 border-2 border-blue-300 p-6"
              >
                <h3 className="font-display font-bold text-lg mb-4 text-blue-800">
                  Payment Verification Required
                </h3>
                <p className="text-blue-700 mb-6">
                  Review the payment screenshot and verify the transaction before approving.
                </p>
                <div className="flex gap-4">
                  <Button
                    onClick={() => setShowApproveDialog(true)}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white border-2 border-black shadow-brutalist"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Approve Order
                  </Button>
                  <Button
                    onClick={() => setShowRejectDialog(true)}
                    variant="outline"
                    className="border-2 border-black text-red-600 hover:bg-red-50"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Reject Order
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Credentials (if completed) */}
            {order.status === 'completed' && order.credentials && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-emerald-50 border-2 border-emerald-300 p-6"
              >
                <h3 className="font-display font-bold text-lg mb-4 text-emerald-800">
                  Assigned Credentials
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Email</p>
                    <p className="font-mono">{order.credentials.email}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Password</p>
                    <p className="font-mono">{order.credentials.password}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Platform</p>
                    <p className="font-mono">{order.credentials.platformLink}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 uppercase">Expiry</p>
                    <p className="font-mono">{order.credentials.expiryDate}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Cancellation Reason */}
            {order.status === 'cancelled' && order.cancellationReason && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-red-50 border-2 border-red-300 p-6"
              >
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                  <div>
                    <h3 className="font-display font-bold text-lg text-red-800 mb-2">
                      Cancellation Reason
                    </h3>
                    <p className="text-red-700">{order.cancellationReason}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar - Timeline */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white border-2 border-black shadow-brutalist p-6"
            >
              <h3 className="font-display font-bold text-lg mb-6">Order Timeline</h3>
              <div className="space-y-0">
                {order.statusLogs.map((log, index) => (
                  <div key={index} className="relative pl-8 pb-6 last:pb-0">
                    {index < order.statusLogs.length - 1 && (
                      <div className="absolute left-[11px] top-6 w-0.5 h-full bg-gray-200" />
                    )}
                    <div className={`absolute left-0 top-1 w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      log.status === 'completed' ? 'bg-emerald-500 border-emerald-600' :
                      log.status === 'cancelled' ? 'bg-red-500 border-red-600' :
                      log.status === 'submitted' ? 'bg-blue-500 border-blue-600' :
                      'bg-amber-500 border-amber-600'
                    }`}>
                      <Check className="h-3 w-3 text-white" />
                    </div>
                    <div>
                      <p className="font-medium capitalize">{log.status}</p>
                      <p className="text-xs text-gray-500 uppercase tracking-wider mt-1">
                        {format(new Date(log.timestamp), 'MMM d, yyyy • h:mm a')}
                      </p>
                      {log.note && (
                        <p className="text-sm text-gray-600 mt-1">{log.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Approve Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent className="border-2 border-black">
          <DialogHeader>
            <DialogTitle className="font-display">Approve Order</DialogTitle>
            <DialogDescription>
              Assign credentials to complete this order.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Quick Select from Pool */}
            {availableAccounts.length > 0 && (
              <div className="mb-4">
                <Label>Quick Select from Pool</Label>
                <div className="mt-2 space-y-2">
                  {availableAccounts.map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => handleSelectAccount(acc.id)}
                      className="w-full text-left p-3 border-2 border-gray-200 hover:border-[#0A7A7A] transition-colors"
                    >
                      <p className="font-mono text-sm">{acc.email}</p>
                      <p className="text-xs text-gray-500">Expires: {acc.expiryDate}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                value={credentials.email}
                onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                className="border-2 border-black"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                value={credentials.password}
                onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                className="border-2 border-black"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="platformLink">Platform Link</Label>
              <Input
                id="platformLink"
                value={credentials.platformLink}
                onChange={(e) => setCredentials(prev => ({ ...prev, platformLink: e.target.value }))}
                className="border-2 border-black"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="expiryDate">Expiry Date</Label>
              <Input
                id="expiryDate"
                type="date"
                value={credentials.expiryDate}
                onChange={(e) => setCredentials(prev => ({ ...prev, expiryDate: e.target.value }))}
                className="border-2 border-black"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleApprove}
              disabled={processing || !credentials.email || !credentials.password}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Approve Order'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="border-2 border-black">
          <DialogHeader>
            <DialogTitle className="font-display">Reject Order</DialogTitle>
            <DialogDescription>
              Provide a reason for rejecting this order.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="reason">Rejection Reason</Label>
            <Textarea
              id="reason"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="e.g., Payment screenshot unclear, transaction ID not visible..."
              className="mt-2 border-2 border-black"
              rows={4}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleReject}
              disabled={processing || !rejectionReason.trim()}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {processing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Reject Order'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
