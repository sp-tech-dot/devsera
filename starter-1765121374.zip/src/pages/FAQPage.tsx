import { Layout } from '@/components/layout/Layout';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { motion } from 'framer-motion';

const faqs = [
  {
    question: 'How does Devsera Store work?',
    answer: 'Devsera Store provides shared access to premium digital subscriptions at reduced prices. When you purchase a subscription, you receive login credentials for a shared account. This allows you to enjoy premium features at a fraction of the retail cost.'
  },
  {
    question: 'Is this legal?',
    answer: 'We operate within the terms of service of each platform by providing shared access to family or team plans. However, we recommend reviewing each platform\'s terms before purchasing.'
  },
  {
    question: 'How do I make a payment?',
    answer: 'We accept UPI payments. After placing an order, you\'ll be redirected to a payment page with a QR code and UPI ID. Make the payment using any UPI app, take a screenshot, and upload it for verification.'
  },
  {
    question: 'How long does delivery take?',
    answer: 'Delivery times vary by product, typically ranging from 1-12 hours. Once your payment is verified, you\'ll receive your credentials via the order detail page. You\'ll also be notified via email.'
  },
  {
    question: 'What if my credentials don\'t work?',
    answer: 'If your credentials don\'t work within 24 hours of delivery, contact us immediately via Telegram. We\'ll either fix the issue or provide a full refund.'
  },
  {
    question: 'Can I share my credentials with others?',
    answer: 'No, credentials are for personal use only. Sharing credentials may result in account suspension and no refund will be provided in such cases.'
  },
  {
    question: 'What is your refund policy?',
    answer: 'We offer full refunds if: (1) Credentials are not delivered within the promised timeframe, (2) Credentials don\'t work within 24 hours of delivery. No refunds are provided after successful credential delivery and verification.'
  },
  {
    question: 'How do I contact support?',
    answer: 'You can reach our support team via Telegram @devserastore. We typically respond within 1-2 hours during business hours (9 AM - 9 PM IST).'
  },
  {
    question: 'Can I upgrade or extend my subscription?',
    answer: 'Yes! Simply place a new order before your current subscription expires. We recommend ordering 2-3 days before expiry to ensure uninterrupted access.'
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We currently accept UPI payments only. This includes Google Pay, PhonePe, Paytm, and any other UPI-enabled app.'
  }
];

export function FAQPage() {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 sm:mb-12"
        >
          <h1 className="font-display font-bold text-2xl sm:text-4xl md:text-5xl mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-gray-600 text-base sm:text-lg max-w-2xl mx-auto">
            Everything you need to know about Devsera Store and how our service works.
          </p>
        </motion.div>

        {/* FAQ Accordion */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-white border-2 border-black shadow-brutalist px-4 sm:px-6"
              >
                <AccordionTrigger className="text-left font-display font-bold hover:no-underline py-4 sm:py-5 text-sm sm:text-base">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 pb-4 sm:pb-5 text-sm sm:text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        {/* Contact CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mt-16"
        >
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <a
            href="https://t.me/devserastore"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#0A7A7A] hover:bg-[#086666] text-white px-6 py-3 border-2 border-black shadow-brutalist hover:shadow-none transition-all"
          >
            Contact us on Telegram
          </a>
        </motion.div>
      </div>
    </Layout>
  );
}
