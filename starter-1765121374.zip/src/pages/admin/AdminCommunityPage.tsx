import { useEffect, useState } from 'react';
import { CommunityPost } from '@/types';
import { CommunityPostForm } from '@/components/community/CommunityPostForm';
import { CommunityPostCard } from '@/components/community/CommunityPostCard';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Trash2, Edit, Eye, EyeOff } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AdminCommunityPage() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('community_posts')
        .select(`
          *,
          author:profiles!community_posts_author_id_fkey(name, email, is_admin),
          comments:community_comments(count),
          reactions:community_reactions(reaction_type)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const postsWithCounts = data?.map((post: any) => ({
        id: post.id,
        title: post.title,
        content: post.content,
        authorId: post.author_id,
        author: {
          name: post.author.name,
          email: post.author.email,
          isAdmin: post.author.is_admin,
        },
        imageUrl: post.image_url,
        pinned: post.pinned,
        published: post.published,
        createdAt: post.created_at,
        updatedAt: post.updated_at,
        comments: post.comments || [],
        reactions: post.reactions || [],
        reactionCounts: {
          like: post.reactions?.filter((r: any) => r.reaction_type === 'like').length || 0,
          love: post.reactions?.filter((r: any) => r.reaction_type === 'love').length || 0,
          fire: post.reactions?.filter((r: any) => r.reaction_type === 'fire').length || 0,
          clap: post.reactions?.filter((r: any) => r.reaction_type === 'clap').length || 0,
        },
      })) || [];

      setPosts(postsWithCounts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async (data: {
    title: string;
    content: string;
    imageUrl?: string;
    pinned: boolean;
  }) => {
    if (!user) return;

    try {
      const { error } = await supabase.from('community_posts').insert({
        title: data.title,
        content: data.content,
        image_url: data.imageUrl,
        pinned: data.pinned,
        author_id: user.id,
        published: true,
      });

      if (error) throw error;
      setShowForm(false);
      fetchPosts();
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  const handleTogglePublish = async (postId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('community_posts')
        .update({ published: !currentStatus })
        .eq('id', postId);

      if (error) throw error;
      fetchPosts();
    } catch (error) {
      console.error('Error toggling publish status:', error);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return;

    try {
      const { error } = await supabase
        .from('community_posts')
        .delete()
        .eq('id', postId);

      if (error) throw error;
      fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center">
        <div className="text-2xl font-bold">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8] py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center justify-between mb-12">
          <h1 className="text-5xl font-bold">Manage Community</h1>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-[#0A7A7A] hover:bg-[#085858] text-white font-bold uppercase border-2 border-black"
            style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
          >
            {showForm ? 'Cancel' : 'Create New Post'}
          </Button>
        </div>

        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-12"
          >
            <CommunityPostForm onSubmit={handleCreatePost} />
          </motion.div>
        )}

        <div className="space-y-8">
          {posts.length === 0 ? (
            <div className="border-2 border-black p-12 bg-white text-center"
              style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
            >
              <p className="text-xl text-gray-600">No posts yet. Create your first post!</p>
            </div>
          ) : (
            posts.map((post) => (
              <div key={post.id} className="relative">
                <CommunityPostCard post={post} />
                
                {/* Admin Actions */}
                <div className="absolute top-4 right-4 flex gap-2">
                  <Button
                    onClick={() => handleTogglePublish(post.id, post.published)}
                    size="sm"
                    variant="outline"
                    className="border-2 border-black bg-white"
                    style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.15)' }}
                  >
                    {post.published ? (
                      <>
                        <EyeOff className="w-4 h-4 mr-1" />
                        Unpublish
                      </>
                    ) : (
                      <>
                        <Eye className="w-4 h-4 mr-1" />
                        Publish
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={() => handleDeletePost(post.id)}
                    size="sm"
                    variant="outline"
                    className="border-2 border-black bg-white text-red-600 hover:bg-red-50"
                    style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.15)' }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
