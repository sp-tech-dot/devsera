import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your configuration.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Types for database tables
export interface DbProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  original_price: number;
  duration: string;
  delivery_time: string;
  category: string;
  image: string;
  features: string[];
  rules: string[];
  refund_policy: string;
  available: boolean;
  created_at: string;
  updated_at: string;
}

export interface DbProfile {
  id: string;
  email: string;
  name: string;
  whatsapp: string | null;
  telegram: string | null;
  is_admin: boolean;
  created_at: string;
  updated_at: string;
}

export interface DbOrder {
  id: string;
  user_id: string;
  product_id: string;
  status: 'pending' | 'submitted' | 'completed' | 'cancelled';
  payment_screenshot: string | null;
  cancellation_reason: string | null;
  credential_email: string | null;
  credential_password: string | null;
  credential_platform_link: string | null;
  credential_expiry_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbOrderStatusLog {
  id: string;
  order_id: string;
  status: string;
  actor: string;
  note: string | null;
  created_at: string;
}

export interface DbAccountPool {
  id: string;
  product_id: string;
  email: string;
  password: string;
  platform_link: string;
  expiry_date: string;
  status: 'available' | 'assigned' | 'blocked';
  assigned_order_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbSetting {
  id: string;
  key: string;
  value: string;
  created_at: string;
  updated_at: string;
}
