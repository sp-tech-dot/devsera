import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Upload, 
  Save,
  Loader2,
  QrCode,
  MessageCircle,
  Check
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export function AdminSettingsPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { paymentSettings, updatePaymentSettings } = useSettings();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    upiId: paymentSettings.upiId,
    telegramLink: paymentSettings.telegramLink,
    telegramCommunityLink: paymentSettings.telegramCommunityLink,
    whatsappSupport: paymentSettings.whatsappSupport
  });
  const [qrPreview, setQrPreview] = useState<string | null>(paymentSettings.qrCodeImage);
  const [saving, setSaving] = useState(false);

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setQrPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    updatePaymentSettings({
      ...formData,
      qrCodeImage: qrPreview
    });
    
    setSaving(false);
    toast({
      title: "Settings Saved",
      description: "Payment and community settings have been updated successfully.",
    });
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/admin')}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Dashboard</span>
        </button>

        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display font-bold text-4xl mb-2">Settings</h1>
          <p className="text-gray-600">Manage payment and community settings</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Payment Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border-2 border-black shadow-brutalist p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-[#0A7A7A] p-2 text-white">
                <QrCode className="h-5 w-5" />
              </div>
              <h2 className="font-display font-bold text-xl">Payment Settings</h2>
            </div>

            <div className="space-y-6">
              {/* UPI ID */}
              <div className="space-y-2">
                <Label htmlFor="upiId">UPI ID</Label>
                <Input
                  id="upiId"
                  value={formData.upiId}
                  onChange={(e) => setFormData(prev => ({ ...prev, upiId: e.target.value }))}
                  placeholder="yourname@upi"
                  className="border-2 border-black"
                />
                <p className="text-xs text-gray-500">This UPI ID will be shown to customers for payment</p>
              </div>

              {/* QR Code Upload */}
              <div className="space-y-2">
                <Label>Payment QR Code</Label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                
                {qrPreview ? (
                  <div className="relative">
                    <img 
                      src={qrPreview} 
                      alt="Payment QR Code" 
                      className="w-full max-w-[250px] border-2 border-black mx-auto"
                    />
                    <div className="flex gap-2 mt-3 justify-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-black"
                      >
                        Change QR
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setQrPreview(null)}
                        className="border-2 border-black text-red-600 hover:bg-red-50"
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border-2 border-dashed border-gray-300 hover:border-[#0A7A7A] p-8 text-center transition-colors"
                  >
                    <Upload className="h-10 w-10 mx-auto mb-3 text-gray-400" />
                    <p className="text-gray-600">Click to upload QR code</p>
                    <p className="text-sm text-gray-400 mt-1">PNG, JPG up to 2MB</p>
                  </button>
                )}
                <p className="text-xs text-gray-500">
                  Upload your UPI payment QR code. If not uploaded, a QR will be auto-generated from UPI ID.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Community Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white border-2 border-black shadow-brutalist p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-[#0A7A7A] p-2 text-white">
                <MessageCircle className="h-5 w-5" />
              </div>
              <h2 className="font-display font-bold text-xl">Community & Support</h2>
            </div>

            <div className="space-y-6">
              {/* Telegram Support */}
              <div className="space-y-2">
                <Label htmlFor="telegramLink">Telegram Support Link</Label>
                <Input
                  id="telegramLink"
                  value={formData.telegramLink}
                  onChange={(e) => setFormData(prev => ({ ...prev, telegramLink: e.target.value }))}
                  placeholder="https://t.me/yourusername"
                  className="border-2 border-black"
                />
                <p className="text-xs text-gray-500">Direct link to your Telegram for customer support</p>
              </div>

              {/* Telegram Community */}
              <div className="space-y-2">
                <Label htmlFor="telegramCommunityLink">Telegram Community Link</Label>
                <Input
                  id="telegramCommunityLink"
                  value={formData.telegramCommunityLink}
                  onChange={(e) => setFormData(prev => ({ ...prev, telegramCommunityLink: e.target.value }))}
                  placeholder="https://t.me/yourcommunity"
                  className="border-2 border-black"
                />
                <p className="text-xs text-gray-500">Link to your Telegram community/channel for announcements</p>
              </div>

              {/* WhatsApp Support */}
              <div className="space-y-2">
                <Label htmlFor="whatsappSupport">WhatsApp Support Number</Label>
                <Input
                  id="whatsappSupport"
                  value={formData.whatsappSupport}
                  onChange={(e) => setFormData(prev => ({ ...prev, whatsappSupport: e.target.value }))}
                  placeholder="+91 98765 43210"
                  className="border-2 border-black"
                />
                <p className="text-xs text-gray-500">WhatsApp number for customer support</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Save Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-8"
        >
          <Button
            onClick={handleSave}
            disabled={saving}
            className="bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none transition-all px-8 py-6 text-lg"
          >
            {saving ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-5 w-5 mr-2" />
                Save Settings
              </>
            )}
          </Button>
        </motion.div>
      </div>
    </Layout>
  );
}
