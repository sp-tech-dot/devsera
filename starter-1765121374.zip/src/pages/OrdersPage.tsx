import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { OrderStatus } from '@/types';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { ShoppingBag, ChevronRight } from 'lucide-react';

const statusFilters: { label: string; value: OrderStatus | 'all' }[] = [
  { label: 'All Orders', value: 'all' },
  { label: 'Pending', value: 'pending' },
  { label: 'Submitted', value: 'submitted' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' }
];

export function OrdersPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { getOrdersByUserId } = useOrders();
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');

  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  const allOrders = getOrdersByUserId(user!.id);
  const filteredOrders = statusFilter === 'all' 
    ? allOrders 
    : allOrders.filter(o => o.status === statusFilter);

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="font-display font-bold text-2xl sm:text-4xl mb-2">My Orders</h1>
          <p className="text-gray-600 text-sm sm:text-base">Track and manage your orders</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-6 sm:mb-8">
          {statusFilters.map(filter => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setStatusFilter(filter.value)}
              className={`border-2 border-black text-xs sm:text-sm ${
                statusFilter === filter.value 
                  ? 'bg-[#0A7A7A] text-white' 
                  : 'bg-white hover:bg-gray-50'
              }`}
            >
              {filter.label}
            </Button>
          ))}
        </div>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <div className="text-center py-16 bg-white border-2 border-black">
            <ShoppingBag className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h2 className="font-display font-bold text-xl mb-2">No orders found</h2>
            <p className="text-gray-600 mb-6">
              {statusFilter === 'all' 
                ? "You haven't placed any orders yet." 
                : `No ${statusFilter} orders found.`}
            </p>
            <Link to="/products">
              <Button className="bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist">
                Browse Products
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map((order, index) => (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link to={`/orders/${order.id}`}>
                  <div className="bg-white border-2 border-black shadow-brutalist hover:shadow-brutalist-lg transition-all p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
                      {/* Product Image */}
                      <img 
                        src={order.product.image} 
                        alt={order.product.name}
                        className="w-16 h-16 sm:w-20 sm:h-20 object-cover border-2 border-black flex-shrink-0 mx-auto sm:mx-0"
                      />
                      
                      {/* Order Info */}
                      <div className="flex-1 min-w-0 text-center sm:text-left">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4 mb-2">
                          <h3 className="font-display font-bold text-base sm:text-lg truncate">
                            {order.product.name}
                          </h3>
                          <StatusBadge status={order.status} />
                        </div>
                        <p className="text-xs sm:text-sm text-gray-600 mb-1">
                          Order ID: <span className="font-mono break-all">{order.id}</span>
                        </p>
                        <p className="text-xs sm:text-sm text-gray-500">
                          {format(new Date(order.createdAt), 'MMM d, yyyy • h:mm a')}
                        </p>
                      </div>

                      {/* Price & Arrow */}
                      <div className="flex items-center justify-center sm:justify-end gap-3 sm:gap-4 mt-3 sm:mt-0">
                        <div className="text-center sm:text-right">
                          <p className="font-display font-bold text-lg sm:text-xl text-[#0A7A7A]">
                            ₹{order.product.price}
                          </p>
                        </div>
                        <ChevronRight className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
