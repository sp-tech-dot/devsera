import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import { ArrowLeft, Copy, Upload, CheckCircle, Clock, Shield, Smartphone, CreditCard, QrCode, MessageCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from '@/components/ui/use-toast';

export function PaymentPageNew() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { getOrderById, updateOrderStatus } = useOrders();
  const { user } = useAuth();
  const { paymentSettings } = useSettings();
  const [uploading, setUploading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [paymentStep, setPaymentStep] = useState<'payment' | 'upload' | 'success'>('payment');

  const order = orderId ? getOrderById(orderId) : null;

  useEffect(() => {
    if (!order || !user) {
      navigate('/orders');
      return;
    }

    if (order.status !== 'pending') {
      setPaymentStep('success');
    }
  }, [order, user, navigate]);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`,
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmitPayment = async () => {
    if (!uploadedFile || !order) return;

    setUploading(true);
    try {
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      await updateOrderStatus(order.id, 'submitted', 'Payment screenshot uploaded');
      setPaymentStep('success');
      
      toast({
        title: "Payment Submitted!",
        description: "Your payment proof has been submitted for verification.",
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload payment proof. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  if (!order) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold mb-4">Order not found</h1>
          <Button onClick={() => navigate('/orders')}>
            Go to Orders
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {/* Back Button */}
          <button 
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 sm:mb-8 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back</span>
          </button>

          <div className="max-w-4xl mx-auto">
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="flex items-center justify-center space-x-8">
                <div className={`flex items-center ${paymentStep === 'payment' ? 'text-blue-600' : 'text-green-600'}`}>
                  <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                    paymentStep === 'payment' ? 'border-blue-600 bg-blue-600 text-white' : 'border-green-600 bg-green-600 text-white'
                  }`}>
                    {paymentStep === 'payment' ? '1' : <CheckCircle className="h-4 w-4" />}
                  </div>
                  <span className="ml-2 font-medium">Payment</span>
                </div>
                <div className={`w-16 h-0.5 ${paymentStep !== 'payment' ? 'bg-green-600' : 'bg-gray-300'}`} />
                <div className={`flex items-center ${paymentStep === 'upload' ? 'text-blue-600' : paymentStep === 'success' ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                    paymentStep === 'upload' ? 'border-blue-600 bg-blue-600 text-white' : 
                    paymentStep === 'success' ? 'border-green-600 bg-green-600 text-white' : 'border-gray-300'
                  }`}>
                    {paymentStep === 'success' ? <CheckCircle className="h-4 w-4" /> : '2'}
                  </div>
                  <span className="ml-2 font-medium">Upload Proof</span>
                </div>
                <div className={`w-16 h-0.5 ${paymentStep === 'success' ? 'bg-green-600' : 'bg-gray-300'}`} />
                <div className={`flex items-center ${paymentStep === 'success' ? 'text-green-600' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center ${
                    paymentStep === 'success' ? 'border-green-600 bg-green-600 text-white' : 'border-gray-300'
                  }`}>
                    {paymentStep === 'success' ? <CheckCircle className="h-4 w-4" /> : '3'}
                  </div>
                  <span className="ml-2 font-medium">Verification</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Order Summary */}
              <div className="lg:col-span-1">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white rounded-2xl border border-gray-200 shadow-lg p-6 sticky top-8"
                >
                  <h3 className="font-bold text-lg mb-4 text-gray-800">Order Summary</h3>
                  
                  <div className="flex items-center gap-4 mb-6">
                    <img 
                      src={order.product.image} 
                      alt={order.product.name}
                      className="w-16 h-16 object-cover rounded-lg border"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-gray-800 truncate">{order.product.name}</h4>
                      <p className="text-sm text-gray-600">{order.product.duration}</p>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Original Price</span>
                      <span className="line-through text-gray-400">₹{order.product.originalPrice}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Discount</span>
                      <span className="text-green-600">-₹{order.product.originalPrice - order.product.price}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span className="text-blue-600">₹{order.product.price}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-xs text-gray-600 mb-2">Order ID</p>
                    <p className="font-mono text-sm break-all">{order.id}</p>
                  </div>
                </motion.div>
              </div>

              {/* Payment Section */}
              <div className="lg:col-span-2">
                {paymentStep === 'payment' && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-2xl border border-gray-200 shadow-lg p-8"
                  >
                    <div className="text-center mb-8">
                      <h1 className="font-bold text-2xl text-gray-800 mb-2">Complete Your Payment</h1>
                      <p className="text-gray-600">Scan QR code or use UPI ID to pay securely</p>
                    </div>

                    {/* Payment Methods */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                      {/* QR Code */}
                      <div className="text-center">
                        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-4">
                          <QrCode className="h-6 w-6 text-blue-600 mx-auto mb-3" />
                          <h3 className="font-semibold text-gray-800 mb-4">Scan QR Code</h3>
                          <div className="bg-white rounded-xl p-4 border-2 border-blue-200 inline-block">
                            {paymentSettings.qrCodeImage ? (
                              <img
                                src={paymentSettings.qrCodeImage}
                                alt="UPI QR Code"
                                className="w-48 h-48 object-contain"
                              />
                            ) : (
                              <img
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=upi://pay?pa=${paymentSettings.upiId}&pn=Devsera%20Store&am=${order.product.price}&cu=INR`}
                                alt="UPI QR Code"
                                className="w-48 h-48"
                              />
                            )}
                          </div>
                        </div>
                      </div>

                      {/* UPI ID */}
                      <div>
                        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 mb-4">
                          <Smartphone className="h-6 w-6 text-green-600 mx-auto mb-3" />
                          <h3 className="font-semibold text-gray-800 mb-4 text-center">Pay using UPI ID</h3>
                          
                          <div className="space-y-4">
                            <div className="bg-white rounded-lg border-2 border-green-200 p-4">
                              <p className="text-sm text-gray-600 mb-2">UPI ID</p>
                              <div className="flex items-center justify-between">
                                <code className="font-mono text-sm text-gray-800 break-all">
                                  {paymentSettings.upiId}
                                </code>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyToClipboard(paymentSettings.upiId, 'UPI ID')}
                                  className="ml-2 border-green-300 text-green-700 hover:bg-green-50"
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>

                            <div className="bg-white rounded-lg border-2 border-green-200 p-4">
                              <p className="text-sm text-gray-600 mb-2">Amount</p>
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-lg text-green-600">₹{order.product.price}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => copyToClipboard(order.product.price.toString(), 'Amount')}
                                  className="border-green-300 text-green-700 hover:bg-green-50"
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Security Features */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 mb-8">
                      <div className="flex items-center gap-3 mb-4">
                        <Shield className="h-5 w-5 text-blue-600" />
                        <h3 className="font-semibold text-gray-800">Secure Payment</h3>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>256-bit SSL Encryption</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>UPI Certified</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>Instant Verification</span>
                        </div>
                      </div>
                    </div>

                    {/* Next Step */}
                    <div className="text-center">
                      <Button
                        onClick={() => setPaymentStep('upload')}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg"
                      >
                        I've Made the Payment
                      </Button>
                      <p className="text-sm text-gray-500 mt-3">
                        Click after completing the payment to upload proof
                      </p>
                    </div>
                  </motion.div>
                )}

                {paymentStep === 'upload' && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-2xl border border-gray-200 shadow-lg p-8"
                  >
                    <div className="text-center mb-8">
                      <Upload className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                      <h1 className="font-bold text-2xl text-gray-800 mb-2">Upload Payment Proof</h1>
                      <p className="text-gray-600">Upload a screenshot of your successful payment</p>
                    </div>

                    <div className="max-w-md mx-auto">
                      <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center mb-6 hover:border-blue-400 transition-colors">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                          id="payment-proof"
                        />
                        <label htmlFor="payment-proof" className="cursor-pointer">
                          <Upload className="h-8 w-8 text-gray-400 mx-auto mb-3" />
                          <p className="text-gray-600 mb-2">Click to upload screenshot</p>
                          <p className="text-sm text-gray-400">PNG, JPG up to 10MB</p>
                        </label>
                      </div>

                      {uploadedFile && (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                          <div className="flex items-center gap-3">
                            <CheckCircle className="h-5 w-5 text-green-600" />
                            <div>
                              <p className="font-medium text-green-800">{uploadedFile.name}</p>
                              <p className="text-sm text-green-600">Ready to upload</p>
                            </div>
                          </div>
                        </div>
                      )}

                      <Button
                        onClick={handleSubmitPayment}
                        disabled={!uploadedFile || uploading}
                        className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-3 rounded-xl font-semibold shadow-lg disabled:opacity-50"
                      >
                        {uploading ? 'Uploading...' : 'Submit Payment Proof'}
                      </Button>
                    </div>
                  </motion.div>
                )}

                {paymentStep === 'success' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white rounded-2xl border border-gray-200 shadow-lg p-8 text-center"
                  >
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                    <h1 className="font-bold text-2xl text-gray-800 mb-4">Payment Submitted Successfully!</h1>
                    <p className="text-gray-600 mb-8">
                      Your payment proof has been submitted for verification. You'll receive your account credentials within {order.product.deliveryTime}.
                    </p>
                    
                    <div className="space-y-4">
                      <Button
                        onClick={() => navigate(`/orders/${order.id}`)}
                        className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 rounded-xl font-semibold"
                      >
                        View Order Details
                      </Button>
                      
                      <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                        <MessageCircle className="h-4 w-4" />
                        <span>Need help? </span>
                        <a 
                          href={paymentSettings.telegramLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          Contact Support
                        </a>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>
            </div>

            {/* Help Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-12 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200 p-6"
            >
              <div className="flex items-start gap-4">
                <AlertCircle className="h-6 w-6 text-amber-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-amber-800 mb-2">Need Help?</h3>
                  <p className="text-amber-700 text-sm mb-4">
                    If you're facing any issues with payment or have questions about the process, our support team is here to help.
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <a
                      href={paymentSettings.telegramLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-amber-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-amber-700 transition-colors"
                    >
                      <MessageCircle className="h-4 w-4" />
                      Telegram Support
                    </a>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate('/faq')}
                      className="border-amber-300 text-amber-700 hover:bg-amber-50"
                    >
                      View FAQ
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}