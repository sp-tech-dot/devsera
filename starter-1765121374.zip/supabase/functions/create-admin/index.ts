import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders, status: 200 })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    
    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY environment variables')
    }
    
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    const { email, password } = await req.json()
    
    if (!email || !password) {
      throw new Error('Email and password are required')
    }

    // Check if user exists
    const { data: existingUsers, error: listError } = await supabaseAdmin.auth.admin.listUsers()
    
    if (listError) {
      throw new Error(`Failed to list users: ${listError.message}`)
    }
    
    const existingUser = existingUsers?.users?.find(u => u.email === email)

    if (existingUser) {
      // Update password for existing user
      const { data, error } = await supabaseAdmin.auth.admin.updateUserById(
        existingUser.id,
        { password: password }
      )
      
      if (error) throw new Error(`Failed to update user: ${error.message}`)

      // Update profile to be admin
      await supabaseAdmin
        .from('profiles')
        .upsert({ 
          id: existingUser.id, 
          email: email,
          is_admin: true 
        })

      return new Response(
        JSON.stringify({ message: 'Admin password updated successfully!', user: data.user }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      )
    } else {
      // Create new admin user
      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email: email,
        password: password,
        email_confirm: true,
        user_metadata: { name: 'Admin User' }
      })

      if (error) throw new Error(`Failed to create user: ${error.message}`)

      // Create/update profile to be admin
      await supabaseAdmin
        .from('profiles')
        .upsert({ 
          id: data.user.id, 
          email: email,
          is_admin: true 
        })

      return new Response(
        JSON.stringify({ message: 'Admin user created successfully!', user: data.user }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      )
    }
  } catch (error: any) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message || 'Unknown error occurred' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )
  }
})
