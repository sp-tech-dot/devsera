import { useEffect, useState } from 'react';
import { CommunityPost, ReactionType } from '@/types';
import { CommunityPostCard } from '@/components/community/CommunityPostCard';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Users, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

export default function CommunityPage() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('community_posts')
        .select(`
          *,
          author:profiles!community_posts_author_id_fkey(name, email, is_admin),
          comments:community_comments(count),
          reactions:community_reactions(reaction_type)
        `)
        .eq('published', true)
        .order('pinned', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) throw error;

      const postsWithCounts = data?.map((post: any) => ({
        id: post.id,
        title: post.title,
        content: post.content,
        authorId: post.author_id,
        author: {
          name: post.author.name,
          email: post.author.email,
          isAdmin: post.author.is_admin,
        },
        imageUrl: post.image_url,
        pinned: post.pinned,
        published: post.published,
        createdAt: post.created_at,
        updatedAt: post.updated_at,
        comments: post.comments || [],
        reactions: post.reactions || [],
        reactionCounts: {
          like: post.reactions?.filter((r: any) => r.reaction_type === 'like').length || 0,
          love: post.reactions?.filter((r: any) => r.reaction_type === 'love').length || 0,
          fire: post.reactions?.filter((r: any) => r.reaction_type === 'fire').length || 0,
          clap: post.reactions?.filter((r: any) => r.reaction_type === 'clap').length || 0,
        },
      })) || [];

      setPosts(postsWithCounts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReact = async (postId: string, reactionType: ReactionType) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('community_reactions')
        .upsert({
          post_id: postId,
          user_id: user.id,
          reaction_type: reactionType,
        });

      if (error) throw error;
      fetchPosts();
    } catch (error) {
      console.error('Error adding reaction:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center">
        <div className="text-2xl font-bold">Loading community...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAF8]">
      {/* Hero Section */}
      <section className="bg-[#0A7A7A] text-white py-24 border-b-4 border-black">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-4 mb-6">
              <Users className="w-16 h-16" />
              <h1 className="text-6xl font-bold">Community</h1>
            </div>
            <p className="text-xl max-w-2xl mx-auto opacity-90">
              Stay updated with the latest news, announcements, and tips from the Devsera team
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 border-b-2 border-black bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="border-2 border-black p-6 text-center bg-[#FAFAF8]"
              style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
            >
              <TrendingUp className="w-12 h-12 mx-auto mb-3 text-[#0A7A7A]" />
              <div className="text-4xl font-bold mb-2">{posts.length}</div>
              <div className="text-gray-600 uppercase tracking-wide text-sm">Total Posts</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="border-2 border-black p-6 text-center bg-[#FAFAF8]"
              style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
            >
              <Users className="w-12 h-12 mx-auto mb-3 text-[#0A7A7A]" />
              <div className="text-4xl font-bold mb-2">1000+</div>
              <div className="text-gray-600 uppercase tracking-wide text-sm">Community Members</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="border-2 border-black p-6 text-center bg-[#FAFAF8]"
              style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
            >
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-gray-600 uppercase tracking-wide text-sm">Support Available</div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Posts Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="space-y-8">
            {posts.length === 0 ? (
              <div className="border-2 border-black p-12 bg-white text-center"
                style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
              >
                <p className="text-xl text-gray-600">No posts yet. Check back soon!</p>
              </div>
            ) : (
              posts.map((post) => (
                <CommunityPostCard
                  key={post.id}
                  post={post}
                  onReact={handleReact}
                />
              ))
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
