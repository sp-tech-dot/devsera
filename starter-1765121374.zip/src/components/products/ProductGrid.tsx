import { Product } from '@/types';
import { ProductCard } from './ProductCard';

interface ProductGridProps {
  products: Product[];
  title?: string;
  subtitle?: string;
  viewMode?: 'grid' | 'list';
}

export function ProductGrid({ products, title, subtitle, viewMode = 'grid' }: ProductGridProps) {
  return (
    <section className="py-12 sm:py-16">
      {(title || subtitle) && (
        <div className="mb-8 sm:mb-12">
          {title && (
            <h2 className="font-display font-bold text-2xl sm:text-3xl md:text-4xl mb-2 sm:mb-3">
              {title}
            </h2>
          )}
          {subtitle && (
            <p className="text-gray-600 text-base sm:text-lg max-w-2xl">
              {subtitle}
            </p>
          )}
        </div>
      )}
      
      <div className={
        viewMode === 'grid' 
          ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 lg:gap-6" 
          : "space-y-4"
      }>
        {products.map((product, index) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            index={index} 
            viewMode={viewMode}
          />
        ))}
      </div>
    </section>
  );
}
