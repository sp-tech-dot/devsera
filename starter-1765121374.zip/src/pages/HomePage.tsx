import { Link } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ProductGrid } from '@/components/products/ProductGrid';
import { Button } from '@/components/ui/button';
import { useOrders } from '@/contexts/OrderContext';
import { Shield, Zap, HeadphonesIcon, CreditCard } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: Shield,
    title: 'Secure Payments',
    description: 'UPI payments with screenshot verification for complete transparency'
  },
  {
    icon: Zap,
    title: 'Fast Delivery',
    description: 'Get your credentials within hours of payment verification'
  },
  {
    icon: HeadphonesIcon,
    title: '24/7 Support',
    description: 'Dedicated Telegram support for all your queries'
  },
  {
    icon: CreditCard,
    title: 'Best Prices',
    description: 'Premium subscriptions at up to 85% off retail prices'
  }
];

export function HomePage() {
  const { products, loading } = useOrders();
  
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b-2 border-black">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0A7A7A]/5 to-transparent" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 md:py-32">
          <div className="max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-block bg-[#0A7A7A] text-white px-3 sm:px-4 py-1 border-2 border-black font-medium text-xs sm:text-sm mb-4 sm:mb-6">
                PREMIUM SUBSCRIPTIONS AT AFFORDABLE PRICES
              </span>
            </motion.div>
            
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="font-display font-bold text-3xl sm:text-4xl md:text-6xl lg:text-7xl leading-tight mb-4 sm:mb-6"
            >
              Get Premium Apps
              <br />
              <span className="text-[#0A7A7A]">Without Premium Prices</span>
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg sm:text-xl text-gray-600 mb-6 sm:mb-8 max-w-2xl"
            >
              Access Canva Pro, LinkedIn Premium, Netflix, Spotify, and more through our 
              trusted shared subscription service. Save up to 85% on your favorite tools.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-3 sm:gap-4"
            >
              <Link to="/products">
                <Button 
                  size="lg"
                  className="w-full sm:w-auto bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black shadow-brutalist hover:shadow-none transition-all active:scale-[0.98] text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6"
                >
                  Browse Products
                </Button>
              </Link>
              <Link to="/faq">
                <Button 
                  variant="outline"
                  size="lg"
                  className="w-full sm:w-auto border-2 border-black shadow-brutalist hover:shadow-none transition-all text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6"
                >
                  How It Works
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 sm:py-16 border-b-2 border-black bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="p-4 sm:p-6 border-2 border-black bg-[#FAFAF8] shadow-brutalist"
              >
                <feature.icon className="h-8 w-8 sm:h-10 sm:w-10 text-[#0A7A7A] mb-3 sm:mb-4" />
                <h3 className="font-display font-bold text-base sm:text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="bg-[#FAFAF8]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="py-16 text-center">
              <div className="w-12 h-12 border-4 border-[#0A7A7A] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-gray-600">Loading products...</p>
            </div>
          ) : (
            <ProductGrid 
              products={products}
              title="Popular Products"
              subtitle="Choose from our curated selection of premium digital subscriptions"
            />
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 sm:py-20 bg-[#1A1A1A] text-white border-t-2 border-black">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-display font-bold text-2xl sm:text-3xl md:text-5xl mb-4 sm:mb-6">
            Ready to Save on Premium Apps?
          </h2>
          <p className="text-gray-400 text-base sm:text-lg mb-6 sm:mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who are enjoying premium subscriptions 
            at a fraction of the cost.
          </p>
          <Link to="/products">
            <Button 
              size="lg"
              className="w-full sm:w-auto bg-[#0A7A7A] hover:bg-[#0FAFAF] text-white border-2 border-white shadow-brutalist hover:shadow-none transition-all active:scale-[0.98] text-base sm:text-lg px-6 sm:px-8 py-4 sm:py-6"
            >
              Get Started Now
            </Button>
          </Link>
        </div>
      </section>
    </Layout>
  );
}
