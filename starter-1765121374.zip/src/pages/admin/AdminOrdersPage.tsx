import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { useOrders } from '@/contexts/OrderContext';
import { useAuth } from '@/contexts/AuthContext';
import { OrderStatus } from '@/types';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { ArrowLeft, Eye } from 'lucide-react';

const statusFilters: { label: string; value: OrderStatus | 'all' }[] = [
  { label: 'All', value: 'all' },
  { label: 'Pending', value: 'pending' },
  { label: 'Submitted', value: 'submitted' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' }
];

export function AdminOrdersPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { orders } = useOrders();
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');

  if (!isAuthenticated || !user?.isAdmin) {
    navigate('/login');
    return null;
  }

  const filteredOrders = statusFilter === 'all' 
    ? orders 
    : orders.filter(o => o.status === statusFilter);

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/admin')}
          className="flex items-center gap-2 text-gray-600 hover:text-black mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Dashboard</span>
        </button>

        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display font-bold text-4xl mb-2">All Orders</h1>
          <p className="text-gray-600">Manage and verify customer orders</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {statusFilters.map(filter => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setStatusFilter(filter.value)}
              className={`border-2 border-black ${
                statusFilter === filter.value 
                  ? 'bg-[#0A7A7A] text-white' 
                  : 'bg-white hover:bg-gray-50'
              }`}
            >
              {filter.label}
              {filter.value !== 'all' && (
                <span className="ml-2 bg-black/20 px-1.5 py-0.5 rounded text-xs">
                  {orders.filter(o => o.status === filter.value).length}
                </span>
              )}
            </Button>
          ))}
        </div>

        {/* Orders Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-2 border-black shadow-brutalist overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-black">
                <tr>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Order ID</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Product</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Amount</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Status</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Date</th>
                  <th className="text-left px-4 py-3 font-display font-bold text-sm">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredOrders.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <span className="font-mono text-sm">{order.id}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img 
                          src={order.product.image} 
                          alt={order.product.name}
                          className="w-10 h-10 object-cover border border-gray-200"
                        />
                        <span className="font-medium">{order.product.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-bold text-[#0A7A7A]">₹{order.product.price}</span>
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={order.status} />
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {format(new Date(order.createdAt), 'MMM d, yyyy')}
                    </td>
                    <td className="px-4 py-3">
                      <Link to={`/admin/orders/${order.id}`}>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="border-2 border-black"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredOrders.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No orders found</p>
            </div>
          )}
        </motion.div>
      </div>
    </Layout>
  );
}
