import { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { OrderProvider } from "@/contexts/OrderContext";
import { SettingsProvider } from "@/contexts/SettingsContext";
import { Toaster } from "@/components/ui/toaster";

// Pages
import { HomePage } from "@/pages/HomePage";
import { ProductsPage } from "@/pages/ProductsPage";
import { ProductDetailPage } from "@/pages/ProductDetailPage";
import { LoginPage } from "@/pages/LoginPage";
import { RegisterPage } from "@/pages/RegisterPage";
import { PaymentPageNew } from "@/pages/PaymentPageNew";
import { OrdersPage } from "@/pages/OrdersPage";
import { OrderDetailPage } from "@/pages/OrderDetailPage";
import { FAQPage } from "@/pages/FAQPage";
import { RefundPolicyPage } from "@/pages/RefundPolicyPage";
import CommunityPageNew from "@/pages/CommunityPageNew";

// Admin Pages
import { AdminDashboardNew } from "@/pages/admin/AdminDashboardNew";
import { AdminOrdersPage } from "@/pages/admin/AdminOrdersPage";
import { AdminOrderDetailPage } from "@/pages/admin/AdminOrderDetailPage";
import { AdminAccountsPage } from "@/pages/admin/AdminAccountsPage";
import { AdminSettingsPage } from "@/pages/admin/AdminSettingsPage";
import AdminCommunityPage from "@/pages/admin/AdminCommunityPage";
import SetupAdminPage from "@/pages/SetupAdminPage";

function App() {
  return (
    <AuthProvider>
      <OrderProvider>
        <SettingsProvider>
          <Suspense fallback={
            <div className="min-h-screen flex items-center justify-center bg-[#FAFAF8]">
              <div className="text-center">
                <div className="w-12 h-12 border-4 border-[#0A7A7A] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-gray-600">Loading...</p>
              </div>
            </div>
          }>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<HomePage />} />
              <Route path="/products" element={<ProductsPage />} />
              <Route path="/products/:id" element={<ProductDetailPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/faq" element={<FAQPage />} />
              <Route path="/refund-policy" element={<RefundPolicyPage />} />
              <Route path="/community" element={<CommunityPageNew />} />
              
              {/* User Routes */}
              <Route path="/payment/:orderId" element={<PaymentPageNew />} />
              <Route path="/orders" element={<OrdersPage />} />
              <Route path="/orders/:orderId" element={<OrderDetailPage />} />
              
              {/* Admin Routes */}
              <Route path="/admin" element={<AdminDashboardNew />} />
              <Route path="/admin/orders" element={<AdminOrdersPage />} />
              <Route path="/admin/orders/:orderId" element={<AdminOrderDetailPage />} />
              <Route path="/admin/accounts" element={<AdminAccountsPage />} />
              <Route path="/admin/settings" element={<AdminSettingsPage />} />
              <Route path="/admin/community" element={<AdminCommunityPage />} />
              <Route path="/setup-admin" element={<SetupAdminPage />} />
            </Routes>
          </Suspense>
          <Toaster />
        </SettingsProvider>
      </OrderProvider>
    </AuthProvider>
  );
}

export default App;
