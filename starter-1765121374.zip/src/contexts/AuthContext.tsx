import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { User, AuthContextType, RegisterData } from '@/types';
import { supabase } from '@/lib/supabase';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
          // Try to get profile from database
          const { data: profile, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', session.user.id)
            .single();
          
          if (profile && !error) {
            setUser({
              id: profile.id,
              email: profile.email,
              name: profile.name,
              whatsapp: profile.whatsapp || undefined,
              telegram: profile.telegram || undefined,
              isAdmin: profile.is_admin,
              createdAt: profile.created_at
            });
          } else {
            // If profile doesn't exist in database, create a basic user from session
            console.warn('Profile not found in database, using session data');
            setUser({
              id: session.user.id,
              email: session.user.email || '',
              name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
              isAdmin: false,
              createdAt: session.user.created_at || new Date().toISOString()
            });
          }
        } else {
          // Check localStorage for persisted user data
          const persistedUser = localStorage.getItem('devsera_user');
          if (persistedUser) {
            try {
              const userData = JSON.parse(persistedUser);
              setUser(userData);
            } catch (error) {
              console.error('Error parsing persisted user data:', error);
              localStorage.removeItem('devsera_user');
            }
          }
        }
      } catch (error) {
        console.error('Session check error:', error);
        // Check localStorage as fallback
        const persistedUser = localStorage.getItem('devsera_user');
        if (persistedUser) {
          try {
            const userData = JSON.parse(persistedUser);
            setUser(userData);
          } catch (error) {
            console.error('Error parsing persisted user data:', error);
            localStorage.removeItem('devsera_user');
          }
        }
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        
        let userData;
        if (profile && !error) {
          userData = {
            id: profile.id,
            email: profile.email,
            name: profile.name,
            whatsapp: profile.whatsapp || undefined,
            telegram: profile.telegram || undefined,
            isAdmin: profile.is_admin,
            createdAt: profile.created_at
          };
        } else {
          // Fallback to session data if profile not found
          userData = {
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
            isAdmin: false,
            createdAt: session.user.created_at || new Date().toISOString()
          };
        }
        
        setUser(userData);
        // Persist user data to localStorage
        localStorage.setItem('devsera_user', JSON.stringify(userData));
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        localStorage.removeItem('devsera_user');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (data.user) {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();
        
        let userData;
        if (profile && !profileError) {
          userData = {
            id: profile.id,
            email: profile.email,
            name: profile.name,
            whatsapp: profile.whatsapp || undefined,
            telegram: profile.telegram || undefined,
            isAdmin: profile.is_admin,
            createdAt: profile.created_at
          };
        } else {
          // Fallback to session data if profile not found
          userData = {
            id: data.user.id,
            email: data.user.email || '',
            name: data.user.user_metadata?.name || data.user.email?.split('@')[0] || 'User',
            isAdmin: false,
            createdAt: data.user.created_at || new Date().toISOString()
          };
        }
        
        setUser(userData);
        // Persist user data to localStorage
        localStorage.setItem('devsera_user', JSON.stringify(userData));
      }
    } catch (error: any) {
      console.error('Login error:', error);
      throw new Error(error.message || 'Failed to login');
    }
  }, []);

  const register = useCallback(async (data: RegisterData) => {
    try {
      setIsLoading(true);
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password
      });

      if (authError) {
        throw authError;
      }

      if (!authData.user) {
        throw new Error('Registration failed');
      }

      // Wait for trigger to create profile
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Update profile
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          name: data.name,
          whatsapp: data.whatsapp || null,
          telegram: data.telegram || null
        })
        .eq('id', authData.user.id);

      if (profileError) {
        throw profileError;
      }

      // Fetch profile
      const { data: profile, error: fetchError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .single();

      if (fetchError || !profile) {
        throw new Error('Failed to create profile');
      }

      const userData = {
        id: profile.id,
        email: profile.email,
        name: profile.name,
        whatsapp: profile.whatsapp || undefined,
        telegram: profile.telegram || undefined,
        isAdmin: profile.is_admin,
        createdAt: profile.created_at
      };

      setUser(userData);
      // Persist user data to localStorage
      localStorage.setItem('devsera_user', JSON.stringify(userData));
      setIsLoading(false);
    } catch (error: any) {
      setIsLoading(false);
      throw new Error(error.message || 'Registration failed');
    }
  }, []);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    localStorage.removeItem('devsera_user');
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      register,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
