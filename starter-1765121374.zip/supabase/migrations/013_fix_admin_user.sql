DO $$
DECLARE
  admin_id UUID;
BEGIN
  SELECT id INTO admin_id FROM auth.users WHERE email = 'admin@devsera.store';
  
  IF admin_id IS NULL THEN
    admin_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      role,
      aud
    ) VALUES (
      admin_id,
      '00000000-0000-0000-0000-000000000000',
      'admin@devsera.store',
      crypt('Stevesp123@', gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{"name":"Admin User"}',
      false,
      'authenticated',
      'authenticated'
    );
    
    INSERT INTO auth.identities (
      id,
      user_id,
      identity_data,
      provider,
      provider_id,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      admin_id,
      admin_id,
      jsonb_build_object('sub', admin_id::text, 'email', 'admin@devsera.store'),
      'email',
      admin_id::text,
      NOW(),
      NOW(),
      NOW()
    );
    
    INSERT INTO profiles (id, email, name, is_admin)
    VALUES (admin_id, 'admin@devsera.store', 'Admin User', true)
    ON CONFLICT (id) DO UPDATE SET is_admin = true;
  ELSE
    UPDATE auth.users 
    SET encrypted_password = crypt('Stevesp123@', gen_salt('bf'))
    WHERE id = admin_id;
    
    UPDATE profiles SET is_admin = true WHERE id = admin_id;
  END IF;
END $$;
