import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ImagePlus } from 'lucide-react';

interface CommunityPostFormProps {
  onSubmit: (data: {
    title: string;
    content: string;
    imageUrl?: string;
    pinned: boolean;
  }) => Promise<void>;
  isLoading?: boolean;
}

export function CommunityPostForm({ onSubmit, isLoading }: CommunityPostFormProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [pinned, setPinned] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit({ title, content, imageUrl: imageUrl || undefined, pinned });
    setTitle('');
    setContent('');
    setImageUrl('');
    setPinned(false);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="border-2 border-black p-6 bg-white"
      style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
    >
      <h3 className="text-2xl font-bold mb-6">Create New Post</h3>

      <div className="space-y-4">
        <div>
          <Label htmlFor="title" className="uppercase tracking-wide text-sm font-bold">
            Post Title
          </Label>
          <Input
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Enter post title..."
            required
            className="border-2 border-black mt-2"
          />
        </div>

        <div>
          <Label htmlFor="content" className="uppercase tracking-wide text-sm font-bold">
            Content
          </Label>
          <Textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your post content..."
            rows={6}
            required
            className="border-2 border-black mt-2"
          />
        </div>

        <div>
          <Label htmlFor="imageUrl" className="uppercase tracking-wide text-sm font-bold flex items-center gap-2">
            <ImagePlus className="w-4 h-4" />
            Image URL (Optional)
          </Label>
          <Input
            id="imageUrl"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="border-2 border-black mt-2"
          />
        </div>

        <div className="flex items-center gap-3 p-4 border-2 border-black bg-[#FAFAF8]">
          <Switch
            id="pinned"
            checked={pinned}
            onCheckedChange={setPinned}
          />
          <Label htmlFor="pinned" className="uppercase tracking-wide text-sm font-bold cursor-pointer">
            Pin this post to top
          </Label>
        </div>

        <Button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#0A7A7A] hover:bg-[#085858] text-white font-bold uppercase tracking-wide border-2 border-black"
          style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
        >
          {isLoading ? 'Publishing...' : 'Publish Post'}
        </Button>
      </div>
    </form>
  );
}
