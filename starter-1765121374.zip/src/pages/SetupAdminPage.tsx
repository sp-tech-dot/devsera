import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function SetupAdminPage() {
  const [email, setEmail] = useState('admin@devsera.store');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSetupAdmin = async () => {
    setLoading(true);
    setMessage('');
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('supabase-functions-create-admin', {
        body: { email, password }
      });

      if (fnError) {
        throw new Error(fnError.message || 'Edge function error');
      }
      
      if (data?.error) {
        throw new Error(data.error);
      }

      setMessage(data?.message || 'Admin user created/updated successfully!');
    } catch (err: any) {
      setError(err.message || 'Failed to setup admin');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAF8] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border-2 border-black p-8 shadow-[4px_4px_0_rgba(0,0,0,0.15)]">
        <h1 className="font-['Space_Grotesk'] text-2xl font-bold mb-6">Setup Admin User</h1>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="email">Admin Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-2 border-black"
            />
          </div>
          
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter admin password"
              className="border-2 border-black"
            />
          </div>

          {message && (
            <div className="p-3 bg-emerald-100 border-2 border-emerald-500 text-emerald-700">
              {message}
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-100 border-2 border-rose-500 text-rose-700">
              {error}
            </div>
          )}

          <Button
            onClick={handleSetupAdmin}
            disabled={loading || !password}
            className="w-full bg-[#0A7A7A] hover:bg-[#086666] text-white border-2 border-black"
          >
            {loading ? 'Setting up...' : 'Create/Update Admin'}
          </Button>
        </div>

        <p className="mt-4 text-sm text-gray-600">
          This page creates or updates the admin user using Supabase Admin API.
          Delete this page after setup.
        </p>
      </div>
    </div>
  );
}
