import { CommunityPost, ReactionType } from '@/types';
import { Heart, Flame, HandMetal, ThumbsUp, MessageCircle, Pin } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

interface CommunityPostCardProps {
  post: CommunityPost;
  onReact?: (postId: string, reactionType: ReactionType) => void;
  onComment?: (postId: string) => void;
}

const reactionIcons = {
  like: ThumbsUp,
  love: Heart,
  fire: Flame,
  clap: HandMetal,
};

const reactionColors = {
  like: 'text-blue-500',
  love: 'text-rose-500',
  fire: 'text-orange-500',
  clap: 'text-purple-500',
};

export function CommunityPostCard({ post, onReact, onComment }: CommunityPostCardProps) {
  const [selectedReaction, setSelectedReaction] = useState<ReactionType | null>(null);

  const handleReaction = (type: ReactionType) => {
    setSelectedReaction(type);
    onReact?.(post.id, type);
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="border-2 border-black bg-white overflow-hidden"
      style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
    >
      {/* Header */}
      <div className="p-6 border-b-2 border-black bg-[#FAFAF8]">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#0A7A7A] border-2 border-black flex items-center justify-center text-white font-bold text-xl">
              {post.author?.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg">{post.author?.name}</h3>
                {post.author?.isAdmin && (
                  <span className="bg-[#0A7A7A] text-white text-xs px-2 py-1 border border-black uppercase tracking-wide">
                    Admin
                  </span>
                )}
              </div>
              <p className="text-sm text-gray-600">
                {new Date(post.createdAt).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>
          {post.pinned && (
            <div className="flex items-center gap-1 text-[#F59E0B] font-bold uppercase text-sm">
              <Pin className="w-4 h-4 fill-current" />
              Pinned
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">{post.title}</h2>
        <div className="prose max-w-none mb-4">
          <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">{post.content}</p>
        </div>
        {post.imageUrl && (
          <img
            src={post.imageUrl}
            alt={post.title}
            className="w-full border-2 border-black mt-4"
            style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
          />
        )}
      </div>

      {/* Reactions & Comments */}
      <div className="border-t-2 border-black p-4 bg-[#FAFAF8]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {(Object.keys(reactionIcons) as ReactionType[]).map((type) => {
              const Icon = reactionIcons[type];
              const count = post.reactionCounts?.[type] || 0;
              const isSelected = selectedReaction === type;
              
              return (
                <button
                  key={type}
                  onClick={() => handleReaction(type)}
                  className={`flex items-center gap-1 px-3 py-2 border-2 border-black transition-all hover:scale-105 ${
                    isSelected ? 'bg-black text-white' : 'bg-white'
                  }`}
                  style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.15)' }}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : reactionColors[type]}`} />
                  {count > 0 && <span className="text-sm font-bold">{count}</span>}
                </button>
              );
            })}
          </div>
          
          <button
            onClick={() => onComment?.(post.id)}
            className="flex items-center gap-2 px-4 py-2 border-2 border-black bg-white hover:bg-gray-100 transition-colors"
            style={{ boxShadow: '2px 2px 0 rgba(0,0,0,0.15)' }}
          >
            <MessageCircle className="w-4 h-4" />
            <span className="font-bold">{post.comments?.length || 0}</span>
          </button>
        </div>
      </div>
    </motion.article>
  );
}
