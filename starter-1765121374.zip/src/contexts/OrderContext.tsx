import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { Order, OrderStatus, Product } from '@/types';
import { supabase, DbProduct, DbOrder } from '@/lib/supabase';

interface OrderContextType {
  orders: Order[];
  products: Product[];
  loading: boolean;
  createOrder: (productId: string, userId: string) => Promise<Order>;
  submitPayment: (orderId: string, screenshot: string) => Promise<void>;
  approveOrder: (orderId: string, credentials: Order['credentials']) => Promise<void>;
  rejectOrder: (orderId: string, reason: string) => Promise<void>;
  getOrderById: (orderId: string) => Order | undefined;
  getOrdersByUserId: (userId: string) => Order[];
  getOrdersByStatus: (status: OrderStatus) => Order[];
  getProductById: (productId: string) => Product | undefined;
  refreshOrders: () => Promise<void>;
  refreshProducts: () => Promise<void>;
}

const OrderContext = createContext<OrderContextType | null>(null);

// Helper to convert DB product to app Product type
const mapDbProductToProduct = (dbProduct: DbProduct): Product => ({
  id: dbProduct.id,
  name: dbProduct.name,
  description: dbProduct.description,
  price: dbProduct.price,
  originalPrice: dbProduct.original_price,
  duration: dbProduct.duration,
  deliveryTime: dbProduct.delivery_time,
  category: dbProduct.category,
  image: dbProduct.image,
  features: dbProduct.features || [],
  rules: dbProduct.rules || [],
  refundPolicy: dbProduct.refund_policy,
  available: dbProduct.available
});

// Helper to convert DB order to app Order type
const mapDbOrderToOrder = (dbOrder: DbOrder, product: Product): Order => ({
  id: dbOrder.id,
  userId: dbOrder.user_id,
  productId: dbOrder.product_id,
  product,
  status: dbOrder.status,
  paymentScreenshot: dbOrder.payment_screenshot || undefined,
  cancellationReason: dbOrder.cancellation_reason || undefined,
  credentials: dbOrder.credential_email ? {
    email: dbOrder.credential_email,
    password: dbOrder.credential_password || '',
    platformLink: dbOrder.credential_platform_link || '',
    expiryDate: dbOrder.credential_expiry_date || ''
  } : undefined,
  createdAt: dbOrder.created_at,
  updatedAt: dbOrder.updated_at,
  statusLogs: []
});

export function OrderProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch products from Supabase
  const refreshProducts = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('available', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Supabase error, using mock data:', error);
        // Fallback to mock data if Supabase fails
        const { mockProducts } = await import('@/data/mock-data');
        setProducts(mockProducts);
        return;
      }

      if (data && data.length > 0) {
        const mappedProducts = data.map(mapDbProductToProduct);
        setProducts(mappedProducts);
      } else {
        // If no products in database, use mock data
        const { mockProducts } = await import('@/data/mock-data');
        setProducts(mockProducts);
      }
    } catch (error) {
      console.error('Error fetching products, using mock data:', error);
      // Fallback to mock data on any error
      const { mockProducts } = await import('@/data/mock-data');
      setProducts(mockProducts);
    }
  }, []);

  // Fetch orders from Supabase
  const refreshOrders = useCallback(async () => {
    try {
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;

      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('*');

      if (productsError) throw productsError;

      const productsMap = new Map(
        (productsData || []).map(p => [p.id, mapDbProductToProduct(p)])
      );

      // Fetch status logs for all orders
      const { data: logsData } = await supabase
        .from('order_status_logs')
        .select('*')
        .order('created_at', { ascending: true });

      const logsMap = new Map<string, Order['statusLogs']>();
      (logsData || []).forEach(log => {
        const existing = logsMap.get(log.order_id) || [];
        existing.push({
          status: log.status as OrderStatus,
          timestamp: log.created_at,
          actor: log.actor,
          note: log.note || undefined
        });
        logsMap.set(log.order_id, existing);
      });

      const mappedOrders = (ordersData || []).map(order => {
        const product = productsMap.get(order.product_id);
        if (!product) return null;
        const mappedOrder = mapDbOrderToOrder(order, product);
        mappedOrder.statusLogs = logsMap.get(order.id) || [];
        return mappedOrder;
      }).filter(Boolean) as Order[];

      setOrders(mappedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  }, []);

  // Initial data fetch
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await Promise.all([refreshProducts(), refreshOrders()]);
      setLoading(false);
    };
    fetchData();
  }, [refreshProducts, refreshOrders]);

  const createOrder = useCallback(async (productId: string, userId: string): Promise<Order> => {
    const product = products.find(p => p.id === productId);
    if (!product) throw new Error('Product not found');

    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .insert({
        user_id: userId,
        product_id: productId,
        status: 'pending'
      })
      .select()
      .single();

    if (orderError) throw orderError;

    // Create status log
    await supabase
      .from('order_status_logs')
      .insert({
        order_id: orderData.id,
        status: 'pending',
        actor: 'system',
        note: 'Order created'
      });

    const newOrder = mapDbOrderToOrder(orderData, product);
    newOrder.statusLogs = [{
      status: 'pending',
      timestamp: new Date().toISOString(),
      actor: 'system',
      note: 'Order created'
    }];

    setOrders(prev => [newOrder, ...prev]);
    return newOrder;
  }, [products]);

  const submitPayment = useCallback(async (orderId: string, screenshot: string) => {
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'submitted',
        payment_screenshot: screenshot
      })
      .eq('id', orderId);

    if (error) throw error;

    // Create status log
    const order = orders.find(o => o.id === orderId);
    await supabase
      .from('order_status_logs')
      .insert({
        order_id: orderId,
        status: 'submitted',
        actor: order?.userId || 'user',
        note: 'Payment screenshot uploaded'
      });

    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'submitted' as OrderStatus,
          paymentScreenshot: screenshot,
          updatedAt: new Date().toISOString(),
          statusLogs: [
            ...order.statusLogs,
            {
              status: 'submitted' as OrderStatus,
              timestamp: new Date().toISOString(),
              actor: order.userId,
              note: 'Payment screenshot uploaded'
            }
          ]
        };
      }
      return order;
    }));
  }, [orders]);

  const approveOrder = useCallback(async (orderId: string, credentials: Order['credentials']) => {
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'completed',
        credential_email: credentials?.email,
        credential_password: credentials?.password,
        credential_platform_link: credentials?.platformLink,
        credential_expiry_date: credentials?.expiryDate
      })
      .eq('id', orderId);

    if (error) throw error;

    // Create status log
    await supabase
      .from('order_status_logs')
      .insert({
        order_id: orderId,
        status: 'completed',
        actor: 'admin',
        note: 'Payment verified, credentials assigned'
      });

    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'completed' as OrderStatus,
          credentials,
          updatedAt: new Date().toISOString(),
          statusLogs: [
            ...order.statusLogs,
            {
              status: 'completed' as OrderStatus,
              timestamp: new Date().toISOString(),
              actor: 'admin',
              note: 'Payment verified, credentials assigned'
            }
          ]
        };
      }
      return order;
    }));
  }, []);

  const rejectOrder = useCallback(async (orderId: string, reason: string) => {
    const { error } = await supabase
      .from('orders')
      .update({
        status: 'cancelled',
        cancellation_reason: reason
      })
      .eq('id', orderId);

    if (error) throw error;

    // Create status log
    await supabase
      .from('order_status_logs')
      .insert({
        order_id: orderId,
        status: 'cancelled',
        actor: 'admin',
        note: reason
      });

    setOrders(prev => prev.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'cancelled' as OrderStatus,
          cancellationReason: reason,
          updatedAt: new Date().toISOString(),
          statusLogs: [
            ...order.statusLogs,
            {
              status: 'cancelled' as OrderStatus,
              timestamp: new Date().toISOString(),
              actor: 'admin',
              note: reason
            }
          ]
        };
      }
      return order;
    }));
  }, []);

  const getOrderById = useCallback((orderId: string) => {
    return orders.find(order => order.id === orderId);
  }, [orders]);

  const getOrdersByUserId = useCallback((userId: string) => {
    return orders.filter(order => order.userId === userId);
  }, [orders]);

  const getOrdersByStatus = useCallback((status: OrderStatus) => {
    return orders.filter(order => order.status === status);
  }, [orders]);

  const getProductById = useCallback((productId: string) => {
    return products.find(product => product.id === productId);
  }, [products]);

  return (
    <OrderContext.Provider value={{
      orders,
      products,
      loading,
      createOrder,
      submitPayment,
      approveOrder,
      rejectOrder,
      getOrderById,
      getOrdersByUserId,
      getOrdersByStatus,
      getProductById,
      refreshOrders,
      refreshProducts
    }}>
      {children}
    </OrderContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrders must be used within an OrderProvider');
  }
  return context;
}
