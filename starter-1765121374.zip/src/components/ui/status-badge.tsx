import { cn } from '@/lib/utils';
import { OrderStatus } from '@/types';

interface StatusBadgeProps {
  status: OrderStatus;
  className?: string;
}

const statusConfig: Record<OrderStatus, { label: string; className: string }> = {
  pending: {
    label: 'PENDING',
    className: 'bg-amber-500 text-white border-black'
  },
  submitted: {
    label: 'SUBMITTED',
    className: 'bg-blue-500 text-white border-black'
  },
  completed: {
    label: 'COMPLETED',
    className: 'bg-emerald-500 text-white border-black'
  },
  cancelled: {
    label: 'CANCELLED',
    className: 'bg-rose-500 text-white border-black'
  }
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  
  return (
    <span
      className={cn(
        'inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border-2 shadow-brutalist',
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  );
}
