import { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { motion } from 'framer-motion';

interface ReviewFormProps {
  onSubmit: (rating: number, comment: string) => Promise<void>;
  isLoading?: boolean;
}

export function ReviewForm({ onSubmit, isLoading }: ReviewFormProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;
    await onSubmit(rating, comment);
    setRating(0);
    setComment('');
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="border-2 border-black p-6 bg-[#FAFAF8]"
      style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
    >
      <h3 className="font-bold text-2xl mb-4">Write a Review</h3>
      
      <div className="mb-6">
        <label className="block text-sm font-medium mb-2 uppercase tracking-wide">
          Your Rating
        </label>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoveredRating(star)}
              onMouseLeave={() => setHoveredRating(0)}
              className="transition-transform hover:scale-110"
            >
              <Star
                className={`w-8 h-8 ${
                  star <= (hoveredRating || rating)
                    ? 'fill-amber-400 text-amber-400'
                    : 'text-gray-300'
                }`}
              />
            </button>
          ))}
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium mb-2 uppercase tracking-wide">
          Your Review (Optional)
        </label>
        <Textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Share your experience with this product..."
          rows={4}
          className="border-2 border-black"
        />
      </div>

      <Button
        type="submit"
        disabled={rating === 0 || isLoading}
        className="w-full bg-[#0A7A7A] hover:bg-[#085858] text-white font-bold uppercase tracking-wide border-2 border-black"
        style={{ boxShadow: '4px 4px 0 rgba(0,0,0,0.15)' }}
      >
        {isLoading ? 'Submitting...' : 'Submit Review'}
      </Button>
    </motion.form>
  );
}
