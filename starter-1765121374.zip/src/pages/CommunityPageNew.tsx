import { useState, useEffect } from 'react';
import { CommunityPost, ReactionType } from '@/types';
import { CommunityPostCard } from '@/components/community/CommunityPostCard';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Users, TrendingUp, MessageSquare, Heart, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';

// Mock data for community posts when database is not available
const mockPosts: CommunityPost[] = [
  {
    id: '1',
    title: 'Welcome to Devsera Community! 🎉',
    content: 'Hey everyone! Welcome to our community space where you can share experiences, ask questions, and connect with other users. Feel free to share your success stories, tips, and any feedback about our services.',
    authorId: 'admin',
    author: {
      name: 'Devsera Team',
      email: 'admin@devsera.store',
      isAdmin: true,
    },
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&q=80',
    pinned: true,
    published: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    comments: [],
    reactions: [],
    reactionCounts: {
      like: 15,
      love: 8,
      celebrate: 12,
    },
  },
  {
    id: '2',
    title: 'Tips for Getting the Most Out of Your Canva Pro Subscription',
    content: 'Here are some pro tips to maximize your Canva Pro experience:\n\n1. Use Brand Kit to maintain consistency\n2. Explore premium templates regularly\n3. Take advantage of the background remover\n4. Schedule your social media posts\n5. Collaborate with team members\n\nWhat are your favorite Canva Pro features?',
    authorId: 'user1',
    author: {
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      isAdmin: false,
    },
    imageUrl: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=600&q=80',
    pinned: false,
    published: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    comments: [],
    reactions: [],
    reactionCounts: {
      like: 23,
      love: 5,
      celebrate: 3,
    },
  },
  {
    id: '3',
    title: 'LinkedIn Premium Success Story',
    content: 'Just wanted to share that I landed my dream job thanks to LinkedIn Premium! The InMail credits and profile insights were game-changers. The investment in the subscription paid off within the first month. Thank you Devsera for making premium tools affordable! 🚀',
    authorId: 'user2',
    author: {
      name: 'Mike Chen',
      email: 'mike@example.com',
      isAdmin: false,
    },
    imageUrl: 'https://images.unsplash.com/photo-1611944212129-29977ae1398c?w=600&q=80',
    pinned: false,
    published: true,
    createdAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    updatedAt: new Date(Date.now() - 172800000).toISOString(),
    comments: [],
    reactions: [],
    reactionCounts: {
      like: 45,
      love: 12,
      celebrate: 28,
    },
  },
];

export default function CommunityPageNew() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const { data, error } = await supabase
          .from('community_posts')
          .select(`
            *,
            author:profiles!community_posts_author_id_fkey(name, email, is_admin),
            comments:community_comments(count),
            reactions:community_reactions(reaction_type)
          `)
          .eq('published', true)
          .order('pinned', { ascending: false })
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Database error, using mock data:', error);
          setPosts(mockPosts);
          setLoading(false);
          return;
        }

        if (data && data.length > 0) {
          const postsWithCounts = data?.map((post: any) => ({
            id: post.id,
            title: post.title,
            content: post.content,
            authorId: post.author_id,
            author: {
              name: post.author.name,
              email: post.author.email,
              isAdmin: post.author.is_admin,
            },
            imageUrl: post.image_url,
            pinned: post.pinned,
            published: post.published,
            createdAt: post.created_at,
            updatedAt: post.updated_at,
            comments: post.comments || [],
            reactions: post.reactions || [],
            reactionCounts: {
              like: post.reactions?.filter((r: any) => r.reaction_type === 'like').length || 0,
              love: post.reactions?.filter((r: any) => r.reaction_type === 'love').length || 0,
              celebrate: post.reactions?.filter((r: any) => r.reaction_type === 'celebrate').length || 0,
            },
          })) || [];

          setPosts(postsWithCounts);
        } else {
          // Use mock data if no posts in database
          setPosts(mockPosts);
        }
      } catch (error) {
        console.error('Error fetching posts, using mock data:', error);
        setPosts(mockPosts);
      } finally {
        setLoading(false);
      }
    };

    // Wrap in a microtask to avoid storage access issues in restricted contexts
    Promise.resolve().then(fetchPosts);
  }, []);

  const handleReaction = async (postId: string, reactionType: ReactionType) => {
    if (!user) return;

    try {
      // Check if user already reacted
      const { data: existingReaction } = await supabase
        .from('community_reactions')
        .select('id, reaction_type')
        .eq('post_id', postId)
        .eq('user_id', user.id)
        .single();

      if (existingReaction) {
        if (existingReaction.reaction_type === reactionType) {
          // Remove reaction
          await supabase
            .from('community_reactions')
            .delete()
            .eq('id', existingReaction.id);
        } else {
          // Update reaction
          await supabase
            .from('community_reactions')
            .update({ reaction_type: reactionType })
            .eq('id', existingReaction.id);
        }
      } else {
        // Add new reaction
        await supabase
          .from('community_reactions')
          .insert({
            post_id: postId,
            user_id: user.id,
            reaction_type: reactionType,
          });
      }

      // Refresh posts to update counts
      await fetchPosts();
    } catch (error) {
      console.error('Error handling reaction:', error);
      // For demo purposes, just update local state
      setPosts(prevPosts => 
        prevPosts.map(post => {
          if (post.id === postId) {
            const newCounts = { ...post.reactionCounts };
            newCounts[reactionType] = (newCounts[reactionType] || 0) + 1;
            return { ...post, reactionCounts: newCounts };
          }
          return post;
        })
      );
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          {/* Header */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8 sm:mb-12"
          >
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h1 className="font-display font-bold text-3xl sm:text-4xl md:text-5xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Community
              </h1>
            </div>
            <p className="text-gray-600 text-base sm:text-lg max-w-2xl mx-auto mb-6">
              Connect with fellow users, share experiences, and get the most out of your premium subscriptions
            </p>
            
            {/* Community Stats */}
            <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span>1,200+ Members</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span>{posts.length} Posts</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span>Active Community</span>
              </div>
            </div>
          </motion.div>

          {/* Community Guidelines */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl border border-blue-200 p-6 mb-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <Heart className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-gray-800">Community Guidelines</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
              <div>• Be respectful and supportive</div>
              <div>• Share helpful tips and experiences</div>
              <div>• Keep discussions relevant to our services</div>
            </div>
          </motion.div>

          {/* Posts */}
          <div className="max-w-4xl mx-auto">
            {loading ? (
              <div className="py-20 text-center">
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-6" />
                  <div className="absolute inset-0 w-16 h-16 border-4 border-blue-600 border-b-transparent rounded-full animate-spin mx-auto" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }} />
                </div>
                <h3 className="font-display font-bold text-xl mb-2">Loading Community Posts</h3>
                <p className="text-gray-600">Fetching the latest discussions...</p>
              </div>
            ) : posts.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-20 text-center"
              >
                <div className="w-24 h-24 bg-gray-100 border-2 border-gray-300 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <MessageSquare className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="font-display font-bold text-xl mb-2">No Posts Yet</h3>
                <p className="text-gray-600 mb-6">Be the first to start a conversation in our community!</p>
                {user?.isAdmin && (
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Create First Post
                  </Button>
                )}
              </motion.div>
            ) : (
              <div className="space-y-6">
                {posts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <CommunityPostCard
                      post={post}
                      onReaction={handleReaction}
                      currentUserId={user?.id}
                    />
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}